
from django.contrib.admin import (
    ModelAdmin,TabularInline,StackedInline,AdminSite,site,register,display
)
from django.db.models import Sum
from django.contrib.admin.helpers import AdminForm
from django.db.models.query import QuerySet
from django.http.request import HttpRequest
from django.shortcuts import render
from django.urls.resolvers import URLPattern
from . import models,views
from django.urls import path,reverse
from django.utils.html import format_html
from django.utils.dateparse import parse_date,parse_datetime
import json
from django.http.response import JsonResponse,HttpResponseRedirect
from django.template.response import TemplateResponse
from django.utils.timezone import datetime
from django.contrib.admin.utils import (
    NestedObjects,
    construct_change_message,
    flatten_fieldsets,
    get_deleted_objects,
    lookup_spawns_duplicates,
    model_format_dict,
    model_ngettext,
    quote,
    unquote,
    
)
from django.contrib.admin.utils import (
    display_for_field,
    flatten_fieldsets,
    help_text_for_field,
    label_for_field,
    lookup_field,
    quote,
)
from weasyprint import HTML, CSS
from django.template.loader import render_to_string
import os
from django.conf import settings

from django.contrib.admin.templatetags.admin_list import result_list


class UserModelAdmin(ModelAdmin):
    def get_fields(self, request, obj=None):
        return ["name"]
    list_display = ["id","name","username","_groups","is_active","is_staff"]
    list_editable = ["is_active","is_staff"]
    @display(description="القسم - المجموعة")
    def _groups(self,obj):
        return obj.groups.first().name
    def has_change_permission(self, request, obj=None):
        if not request.user.is_superuser:
            return False
        return super().has_change_permission(request, obj)
def th(content="",style="",classes="text-center",rowspan="",colspan="",style_default="background-color: rgb(10, 169, 169);border: 2px solid black;"):
    return format_html(f"<th  style='{style} {style_default}' class='{classes}' rowspan='{rowspan}' colspan='{colspan}' >{content}</th>")

def td(content="",style="",classes="text-center",rowspan="",colspan="",style_default="border: 1px solid black;"):
    return format_html(f"<td style='{style} {style_default}' class='{classes}' rowspan='{rowspan}' colspan='{colspan}' >{content}</td>")

def row(html="",style="",classes=""):
    return format_html(f"<div style='{style}' class='row {classes}'>{html}</div>")
def col(html="",style="",classes=""):
    return format_html(f"<div style='{style}' class='col {classes}'>{html}</div>")

def table(th_lists=[[]],td_lists=[[]],style="",classes="",style_default="width: 100%;border: 2px solid black;",id=""):
    table_html = f"""<table id="{id}" style="{style} {style_default}" class={classes}>"""
    if th_lists[0]:
        print(77)
        table_html += """<thead>"""
        for th_list in th_lists:
            ths_html = ""
            for th in th_list:
                ths_html += th
            tr_html = f"<tr>{ths_html}</tr>"
            table_html += tr_html
        table_html += "</thead>"

    table_html += "<tbody>"
    for td_list in td_lists:
        tds_html = ""
        for td in td_list:
            tds_html += td
        tr_html = f"<tr>{tds_html}</tr>"
        table_html += tr_html
    table_html += "</tbody>"
    table_html += "</table>"
    return format_html(table_html)
def h(content="",number=4, style="",classes=""):
    return format_html(f"<h{number} style='{style}' class='{classes}' >{content}</h{number}>")
def div(html="",style="",classes=""):
    return format_html(f"<div style='{style}' class='{classes}' >{html}</div>")

def fieldset_field(name=None,width=None,width_label=None):
    return [name,width,width_label]
def fieldset_row(type=1,fields=list):
    return [type,fields]
def fieldset(name=None,fieldset_rows=[]):
    return [name,fieldset_rows]

class BaseReport(ModelAdmin):
    list_per_page = 100
    list_max_show_all = 2000
    viewer_list_template = None
    viewre_form_template = None
    report_title = None
    report_logo = None
    report_logo_2 = None
    
    report_is_horizontal = True
    report_style_list = ["vendor/adminlte/css/adminlte_ar.min.css"]
    report_margin = {"top":"3mm","bottom":"3mm","left":"3mm","right":"3mm"}
    report_address_list = [
       
    ]
    report_footer_list = [
        #"المختص:","المسؤول:",
    ]
    
    report_inline_fieldsets = []
    is_viewer = False
    is_viewer_object = False
    report_fieldsets = []
    report_is_horizontal = True
    def get_list_display(self, request):
        list_display = list(super().get_list_display(request))
        if self.is_viewer_object:
           list_display = list_display + ["viewerform_view_url"]
        return list_display
    @display(description="_")
    def viewerform_view_url(self,obj):
       return format_html(f"""<div class="btn-group btn-group-sm">
                        <a href="{obj.id}/viewer/" class="btn btn-info"><i class="fas fa-eye"></i></a>
                      </div>""")
    
    def report_get_result_fieldsets(self,request,object_id): #-> list[dict[str:dict[str:any]]]:
        result_fieldsets_list = []
        obj = self.get_object(request,object_id)
        
        if self.report_fieldsets:

            for name,fieldset in self.report_fieldsets:
                _row_list=[]
                for row_type,_row in fieldset:
                    _fields_row =[]
                    for field_name, width,width_lable in _row:
                        if field_name:
                            if obj:
                                f,attr,value = lookup_field(field_name,obj,self)
                                if value == None:
                                    value = ""
                            else:
                                if field_name in self.model_form(request).fields:
                                    _field = self.model_form(request)[field_name]
                                    value = _field.value()
                                    if value:
                                        if hasattr(_field.field,"_queryset"):
                                            _queryset = _field.field._queryset
                                            value = _queryset.get(id=value)
                                        elif hasattr(_field.field,"_choices"):
                                            _choices = _field.field._choices
                                            for ch_key,ch_value in _choices:
                                                if ch_key == value:
                                                    value = ch_value
                                    else:
                                        if hasattr(_field.field,"_queryset") or hasattr(_field.field,"_choices"):
                                            value = "الكل"
                                elif hasattr(self,field_name):
                                    value = getattr(self,field_name)(request)
                                    
    
                            _fields_row +=[[field_name,width,width_lable,label_for_field(field_name,self.model,self),value]]
                        else:
                            _fields_row +=[[field_name,width,width_lable,None,None]]
                    _row_list += [[row_type,_fields_row]]
                result_fieldsets_list += [[name,_row_list]]
        
        
        return result_fieldsets_list
    def report_result_fieldsets_html(self,request,object_id):
        content = ""
        for fieldset_name,feldset_rows in self.report_get_result_fieldsets(request,object_id):
            _td_list = []
            for row_type,row_fields in feldset_rows:
                _td_row = []
                for fied_name,field_widh,field_lawidth,field_label,field_value in row_fields:
                    if fied_name:
                        _td_row += [td(f"<b>{field_label}</b>",style=f"width:{field_lawidth};background-color: rgb(10, 169, 169);"),td(field_value,style=f"width:{field_widh}")]
                    else:
                        _td_row += [td("",style=f"width:{field_lawidth};"),td("",style=f"width:{field_widh}")]
                _td_list += [_td_row]
            
            content += row(table(td_lists=_td_list),classes=" mb-1 mt-1")

        return format_html(content)
    def report_get_result_inlines(self,request,object_id):
        obj = self.get_object(request,object_id)
            
        form = self.model_form(request,object_id)
            
        formsets, inline_instances = self._create_formsets(
                request,
                form.instance,
                change=True,
        )
        _results = []
        _result_headers = []
        for inline_formsets in self.get_inline_formsets(request,formsets,inline_instances,obj):
            result_headers = []
            results = []
                
            for qs in inline_formsets.formset.queryset:
                result = []
                for name,field_sets in inline_formsets.model_admin.report_inline_fieldsets:
                    for field in field_sets["fields"]:                            
                        f,attr,value = lookup_field(field,qs,inline_formsets.model_admin)
                        if value == None:
                            value = ""
                        result.append(value)
                results += [result]
                
            for name,field_sets in inline_formsets.model_admin.report_inline_fieldsets:
                for field in field_sets["fields"]:
                    result_headers += [{
                        "text":label_for_field(field,inline_formsets.opts.model,inline_formsets.model_admin),
                    }]
            _result_headers = result_headers
            _results = results
        return {
            "results":_results,
            "result_headers":_result_headers
        }
    

    def report_result_inlines_html(self,request,object_id):
        content = ""
        _results_lists_tds= []
        for result in self.report_get_result_inlines(request,object_id)["results"]:
            _result_list_tds = []
            for re_td in result:
                _result_list_tds += [
                    td(re_td)
                ]
            _results_lists_tds += [_result_list_tds]

        _results_headers_list_ths = []
        for result_header in self.report_get_result_inlines(request,object_id)["result_headers"]:
            _results_headers_list_ths += [
                th(result_header["text"],style="background-color: rgb(10, 169, 169);")
            ]
        content += row(table(th_lists=[_results_headers_list_ths],td_lists=_results_lists_tds,id="example1"),classes="mb-1")
        return format_html(content)
    report_list_display =[]
    def report_get_list_display(self,reques):
        if self.report_list_display:
            return self.report_list_display
        return self.list_display
    def report_result_list_html(self,request):
        cl = self.get_changelist_instance(request)
        cl.formset = None
        cl.show_all = 5000
        cl.can_show_all = True
        cl.list_max_show_all = 5000
        cl.list_display = self.report_get_list_display(request)
        cl.show_admin_actions = False
        cl.list_display_links = None
        

        _result_list = result_list(cl)

        _ths = []
        for result_header in _result_list["result_headers"]:
            _ths += [th(result_header["text"])]
        
        content = row(table(th_lists=[_ths],td_lists=_result_list["results"]),classes="mb-1 mt-1 ")
        return format_html(content)

    def report_get_context(self,request,object_id=None,extra_context=None):
        
        cl = self.get_changelist_instance(request)
        #print(cl,99999999999999)
        cl.formset = None
        inline_result_list = None







        if object_id != None:
            
            obj = self.get_object(request,object_id)
            
            form = self.model_form(request,object_id)
            
            formsets, inline_instances = self._create_formsets(
                request,
                form.instance,
                change=True,
            )
            
            
            inline_result_list = {}
            for inline_formsets in self.get_inline_formsets(request,formsets,inline_instances,obj):
                result_headers = []
                results = []
                
                for qs in inline_formsets.formset.queryset:
                    result = []
                    #print(inline_formsets.opts.__dict__,7)
                    for name,field_sets in inline_formsets.model_admin.report_inline_fieldsets:
                        for field in field_sets["fields"]:
                            #print(field_sets,66)
                            
                            f,attr,value = lookup_field(field,qs,inline_formsets.model_admin)
                            
                            if value == None:
                                value = ""
                                

                            
                            result.append(format_html(f"<td>{value}</td>"))
                    results += [result]
                
                for name,field_sets in inline_formsets.model_admin.report_inline_fieldsets:
                    for field in field_sets["fields"]:
                        result_headers += [{
                            "text":label_for_field(field,inline_formsets.opts.model,inline_formsets.model_admin),
                        }]
                inline_result_list["result_headers"] = result_headers
                inline_result_list["results"] = results
                
                




                #inline_admin_form.readonly_fields = ["medicine"]
        
       
        extra_context = extra_context or {}

        context = {
            "report_result_fieldsets_html":self.report_result_fieldsets_html(request,object_id),
            "report_result_inlines_html":self.report_result_inlines_html(request,object_id),
            "report_result_list_html":self.report_result_list_html(request),

            "result_fieldsets_list":self.report_get_result_fieldsets(request,object_id),
            "inline_result_list":inline_result_list,
            "result_list":result_list(cl),
            "admin_form":self.admin_form(request),
            "logo":self.report_logo or "/static/logo.png",
            "logo_2":self.report_logo_2,
            "title_report": self.report_get_title(request,object_id),
            "address_list":self.report_get_address_list(request,object_id),
            #"footer_list":self.report_get_footer_list(request,object_id),
            "date_report":datetime.now().date(),
            
            "font_Bader":"/static/fonts/Bader.ttf",

            "size":self.report_get_size(),
            "margin":self.report_margin,
        }
        context.update(
            extra_context
        )
        return context
    
    def report_get_size(self,is_horizontal=False):
        if self.report_is_horizontal or is_horizontal:
            return {"width":"204mm","height":"291mm"}
        else:
            return {"width":"291mm","height":"204mm"}

    def report_get_header_list(self,request,object_id):
        return{}
    def report_get_title(self,request,object_id):
        return self.report_title or self.opts.verbose_name_plural
    def report_get_address_list(self,request,object_id):
        return self.report_address_list
    def report_get_footer_list(self,request,object_id):
        return self.report_footer_list
    def report_get_style_list(self):
        return self.report_style_list
    def report_get_pdf_name(self,request,object_id=None):
        return f"{self.report_get_title(request,object_id)}"
    




   
  
    



def render_to_pdf(request, template_name="",pdf_name="test",context={},styles=[]):
    html_string = render_to_string(template_name, context)

    styles = CSS(settings.STATIC_ROOT + '/vendor/adminlte/css/adminlte_ar.min.css')
    

    HTML(string=html_string, base_url=request.build_absolute_uri()).write_pdf(
        os.path.join(settings.MEDIA_ROOT,f"{pdf_name}.pdf"),
         presentational_hints=True,
        stylesheets=[styles], 
    )
    pdf_url = os.path.join(settings.MEDIA_URL,f"{pdf_name}.pdf")
    pdf_viewer_url = settings.STATIC_URL + f"jsPDF-master/examples/PDF.js/web/viewer.html?file={pdf_url}"
    return pdf_viewer_url


def date_format(date):
    return f"{date.year}/{date.month}/{date.day}"




