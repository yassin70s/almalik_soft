
from typing import Any
from django.contrib.admin import *
from django_api_admin.options import APIModelAdmin
from django_api_admin.sites import APIAdminSite
from django.template.response import TemplateResponse
import subprocess
from django.urls import path,reverse
from django.utils.html import format_html
from django.utils.dateparse import parse_date,parse_datetime
import json
from django.contrib.admin.utils import (
    display_for_field,
    flatten_fieldsets,
    help_text_for_field,
    label_for_field,
    lookup_field,
    quote,
)
from django.contrib.admin.helpers import AdminForm
from django.contrib.admin.templatetags.admin_list import result_list
from django.http.response import JsonResponse,HttpResponseRedirect,HttpResponse
from django.utils.timezone import datetime
#from . import models,options
from django.contrib.auth import models as auth_models
from django.contrib.auth import admin as auth_admin
from django.contrib.auth.base_user import AbstractBaseUser
from django.conf import settings
from .options import BaseReport
from django.shortcuts import render
from django.db.models import Sum,Count
from django.contrib.contenttypes import models as contenttypes_models
from .options import fieldset,fieldset_row,fieldset_field,table,th,td,row,col,render_to_pdf
date_naw = datetime.now().date()
class ModelAdmin(BaseReport):
    
    def model_form(self,request,object_id=None):
        obj = None
        change = False
        if object_id != None:
            obj = self.get_object(request,object_id)
            change = True
        fieldsets = self.get_fieldsets(request, obj)
        ModelForm = self.get_form(
            request, obj, change, fields=flatten_fieldsets(fieldsets)
        )
        return ModelForm(request.POST, request.FILES, instance=obj)
    def admin_form(self,request,object_id=None):
        obj = None
        change = False
        if object_id:
            obj = self.get_object(request,object_id)
            change = True
        fieldsets = self.get_fieldsets(request, obj)
        if change and not self.has_change_permission(request, obj):
            readonly_fields = flatten_fieldsets(fieldsets)
        else:
            readonly_fields = self.get_readonly_fields(request, obj)
        form = self.model_form(request,object_id)
        admin_form = AdminForm(
            form,
            list(fieldsets),
            # Clear prepopulated fields on a view-only form to avoid a crash.
            self.get_prepopulated_fields(request, obj)
            if not change or self.has_change_permission(request, obj)
            else {},
            readonly_fields,
            model_admin=self,
        )
        return admin_form
    is_api_change_form = False

    def get_urls(self):
        my_urls = [
            path("viewer/",self.viewerlist_view,name=f"{self.opts.app_label}_{self.opts.model_name}_viewerlist"),
            path("<int:object_id>/viewer/",self.viewerform_view,name=f"{self.opts.app_label}_{self.opts.model_name}_viewer"),

        ]
        if self.is_api_change_form:
            my_urls += [path("api_change_form/",self.api_change_form,name=f"{self.opts.app_label}_{self.opts.model_name}_api_change_form")]
        return my_urls + super().get_urls()
    
    def api_change_form(self,request):
        data = dict(**json.loads(request.body))

        data = self.api_data_form(request,data)
        return JsonResponse(data=data)
    def api_data_form(self,request,data:dict):
        return data
    
    def changelist_view(self, request, extra_context=None):
        if not self.report_is_model_report:
            self.change_list_template = None or [
                f"{self.admin_site.name}/{self.opts.app_label}/{self.opts.model_name}/change_list.html",
                f"{self.admin_site.name}/{self.opts.app_label}/change_list.html",
                f"{self.admin_site.name}/change_list.html",
                f"change_list.html",
                f"admin/change_list.html",
            ]
        
        extra_context = extra_context or {}
        extra_context.update(
            is_viewer = self.is_viewer
        )
        return super().changelist_view(request, extra_context)
    def viewerlist_view(self, request, extra_context=None):
        self.viewer_list_template = None or [
            f"{self.admin_site.name}/{self.opts.app_label}/{self.opts.model_name}/viewer_list.html",
            f"{self.admin_site.name}/{self.opts.app_label}/viewer_list.html",
            f"{self.admin_site.name}/viewer_list.html",
            f"viewer_list.html",
            f"admin/viewer_list.html",
        ]
        context = self.report_get_context(request,None)
        return TemplateResponse(request,self.viewer_list_template,context)
    
    def viewerform_view(self, request, object_id, form_url = "", extra_context = None):
        
        pdf_viewer_url = render_to_pdf(
                    request, 
                    template_name=None or [
            f"{self.admin_site.name}/{self.opts.app_label}/{self.opts.model_name}/viewer_form.html",
            f"{self.admin_site.name}/{self.opts.app_label}/viewer_form.html",
            f"{self.admin_site.name}/viewer_form.html",
            "admin/viewer_form.html"
        ],
        context =self.report_get_context(request,int(object_id),extra_context),
                    styles = self.report_get_style_list(),
                    pdf_name=self.report_get_pdf_name(request,object_id),
                )
        extra_context = extra_context or {}
        extra_context.update(
            **self.changelist_view(request,extra_context).context_data
        )
        extra_context.update(
            title = None,
            subtitle = None
        )
        extra_context.update(
            pdf_viewer_url=pdf_viewer_url
        )

        return TemplateResponse(request,"admin/report_viewer_object.html",extra_context)
    report_is_model_report = False
   
    def changeform_view(self, request, object_id = None, form_url = "", extra_context = None):
        extra_context = extra_context or {}
        if self.is_viewer_object:
            extra_context.update(
                show_save_and_viewer = True
            )
     
                    
                

        self.change_form_template = None or [
            f"{self.admin_site.name}/{self.opts.app_label}/{self.opts.model_name}/change_form.html",
            f"{self.admin_site.name}/{self.opts.app_label}/change_form.html",
            f"{self.admin_site.name}/change_form.html",
            f"change_form.html",
            f"admin/change_form.html",

        ]
        if self.report_is_model_report:
            self.change_form_template = "admin/change_form_report.html"
        extra_context = extra_context or {}
        if self.is_api_change_form:
            extra_context.update(
                is_api_change_form = self.is_api_change_form,
                api_change_form_url = reverse(f"{self.admin_site.name}:{self.opts.app_label}_{self.opts.model_name}_api_change_form")
            )
        return super().changeform_view(request, object_id, form_url, extra_context)

    viewer_template = "repoer/viewer.html"
    

    
class ModelApi(APIModelAdmin):
    pass

class ModelView(ModelAdmin):
    pass

class ModelReport(ModelAdmin):
    actions = None
    list_display_links = None
    list_per_page = 1000
    report_is_model_report = True
    is_viewer = True
    #change_list_template = "report/viewer.html"

    #change_list_template = "admin/report_viewer.html"
    
    def changelist_view(self, request, extra_context=None):
        if not request.method == "POST":
            return HttpResponseRedirect("add/")
        extra_context = extra_context or {}
        
        return self.viewerlist_view(request,extra_context)
    
    
    def changeform_view(self, request, object_id = None, form_url = "", extra_context = None):
        extra_context = extra_context or {}
        extra_context.update(
            title = f"حدد الخيارات المناسبة لإظهار {self.opts.verbose_name_plural}",
            suptitle = f"حدد الخيارات المناسبة لإظهار {self.opts.verbose_name_plural}",
            show_save = False,
            show_save_as_new = False,
            show_save_and_add_another = False,
            show_delete_link = False,
            show_close = False,
        )
        if request.method == "POST":
            if self.model_form(request).is_valid():
                self.data = dict(**self.model_form(request).data)
                extra_context.update(
                    title = None,
                    suptitle = None,
                )
                if "_pdf" in self.data:
                    pdf_viewer_url = render_to_pdf(
                        request, 
                        template_name=None or [
                            f"{self.admin_site.name}/{self.opts.app_label}/{self.opts.model_name}/viewer_list.html",
                            f"{self.admin_site.name}/{self.opts.app_label}/viewer_list.html",
                            f"{self.admin_site.name}/change_list.html",
                            "admin/viewer_list.html"
                        ],
                        context = self.report_get_context(request,None,None),
                        styles = self.report_get_style_list(),
                        pdf_name=self.report_get_pdf_name(request,None),
                    )
                    
                    extra_context.update(

                        **super().changelist_view(request,extra_context).context_data,
                

                            pdf_viewer_url=pdf_viewer_url
                    )
                    return TemplateResponse(request,"admin/report_viewer.html",extra_context)
                elif "_viewer" in self.data:
                    return self.changelist_view(request,extra_context)
                
                elif "_xlsx":
                    return HttpResponse()
                
        
        return super().changeform_view(request, object_id, form_url, extra_context )
    
    """
    def report_get_context(self,request,object_id=None,extra_context=None):
        cl = self.get_changelist_instance(request)
        cl.formset = None
        inline_result_list = None
        result_fieldsets_list = []


        for name,fieldset in self.report_fieldsets:
            _fields = []
            for a_field in fieldset["fields"]:
                if a_field in self.model_form(request).fields:
                    _field = self.model_form(request)[a_field]
                    value = _field.value()
                    if value:
                        if hasattr(_field.field,"_queryset"):
                            _queryset = _field.field._queryset
                            value = _queryset.get(id=value)
                        elif hasattr(_field.field,"_choices"):
                            _choices = _field.field._choices
                            for ch_key,ch_value in _choices:
                                if ch_key == value:
                                    value = ch_value
                    else:
                        if hasattr(_field.field,"_queryset") or hasattr(_field.field,"_choices"):
                            value = "الكل"
                    _fields += [{"name":label_for_field(a_field,self.model,self),"value":value}]
                elif hasattr(self,a_field):
                    _fields += [{"name":label_for_field(a_field,self.model,self),"value":getattr(self,a_field)()}]

            result_fieldsets_list += [{"name":name,"fields":_fields}]
            
        extra_context = extra_context or {}
        for r in result_list(cl)["results"]:
            for h in r:
                print(h,7878)
        context = {
            "result_fieldsets_list":result_fieldsets_list,
            "inline_result_list":inline_result_list,
            "result_list":result_list(cl),
            "admin_form":self.admin_form(request),
            "logo":self.report_logo or "/static/logo.png",
            "title_report": self.report_get_title(request,object_id),
            "address_list":self.report_get_address_list(request,object_id),
            "footer_list":self.report_get_footer_list(request,object_id),
            "date_report":datetime.now().date(),

            "size":self.report_get_size(),
            "margin":self.report_margin,
        }
        extra_context.update(
            context
        )
        return super().report_get_context(request,object_id,extra_context)
    """
class ModelActionReport(BaseReport):
    
    report_is_horizontal = True
    def get_list_display(self, request):
       list_display = list(super().get_list_display(request))
       return list_display + ["report_action_url"]
    def get_list_display(self, request):
       list_display = list(super().get_list_display(request))
       return list_display + ["report_action_url"]
    def get_urls(self):
        return [path("<object_id>/pdf/",self.report_action_admin)] + super().get_urls()
    @display(description="_")
    def report_action_url(self,obj):
       return format_html(f"""<a  href='{obj.id}/pdf/'>طباعة</a>""")
        
        #return format_html(d)
    def report_action_admin(self,request,object_id,extra_context=None):
        
        extra_context = extra_context or {}
        pdf_viewer_url = options.render_to_pdf(
                request, 
                template_name=None or [
                    f"report/{self.opts.app_label}/{self.opts.model_name}/change_object.html",
                    f"report/{self.opts.app_label}/change_object.html",
                    f"report/change_object.html",
                ],
                    context =self.report_get_context(request,object_id,extra_context),
                    styles = self.report_get_style_list(),
                    pdf_name=self.report_get_pdf_name(request,object_id),
                )
        
         
        extra_context.update(
            **self.changeform_view(request,object_id,"",extra_context).context_data
        )
        extra_context.update(
            title = None,
            subtitle = None
        )
        extra_context.update(
            pdf_viewer_url=pdf_viewer_url
        )
        #self.change_list_template = "report/viewer.html"
        return render(request,"report/viewer_object.html",extra_context)

    def report_is_inlines(self):
        if self.inlines:
            return True
        else:
            return False
    def report_viewer(self,request,object_id):
        context = {
            "pdf_viewer_url":reverse(f"{self.admin_site.name}:{self.opts.app_label}_{self.opts.model_name}_changelist") + f"{object_id}/pdf/"
        }
        return TemplateResponse(request,"report/viewer.html",context)




   


class AdminSite(AdminSite):
    site_header = "Almalik"
    site_title = "Almalik"
    index_title = "الرئيسية"
    def __init__(self,name):
        super().__init__(name)
        
    def index(self, request, extra_context = None):
        self.index_template = None or [
            f"{self.name}/index.html",
            f"admin/index.html",
        ]
        return super().index(request, extra_context)
    def app_index(self, request, app_label, extra_context = None):
        self.app_index_template = None or [
            f"{self.name}/{app_label}/index.html",
            f"{self.name}/app_index.html",
        ]
        return super().app_index(request, app_label, extra_context)
    
    def login(self, request, extra_context = None):
        
        return super().login(request, extra_context)
    def logout(self, request, extra_context = None):
        return super().logout(request, extra_context)
    def get_app_list(self, request):
        app_list = list(super().get_app_list(request))
        for app in app_list:
            for model in app["models"]:
                model["model_type"] = self.models_types[model["object_name"]]
        return app_list
    models_types = {}
    def register(self, model_or_iterable, admin_class = None, **options):
        model_type = "Admin"
       
        if type(model_or_iterable) == list:
            models_for = model_or_iterable
        else:
            models_for = [model_or_iterable]

        for model in models_for:
            if admin_class:
                if admin_class.__name__[-5:] == "Admin":
                    model_type = "Admin"
                elif admin_class.__name__[-6:] == "Report":
                    model_type = "Report"
                elif admin_class.__name__[-7:] == "Setting":
                    model_type = "Setting"
                elif admin_class.__name__[-4:] == "View":
                    model_type = "View"
            self.models_types[model._meta.object_name] = model_type
        return super().register(model_or_iterable, admin_class, **options)
admin_site = AdminSite(name="admin_site")


def date_format(date):
    return f"{date.year}/{date.month}/{date.day}"

def day_name(date:datetime)->str:
    days_week = [
        "الإثنين",
        "الثلاثاء",
        "الأربعاء",
        "الخميس",
        "الجمعة",
        "السبت",
        "الأحد",
    ]
    return days_week[date.weekday()]

def month_name(date:datetime)->str:
    days_week = [
        "يناير",
        "فبراير",
        "مارس",
        "إبريل",
        "مايو",
        "يونيو",
        "يوليو",
        "أغسطس",
        "سبتمبو",
        "أكتوبر",
        "نوفمبر",
        "ديسمبر",
    ]
    return days_week[date.month-1]



class ApiSite(APIAdminSite,AdminSite):
    
    def get_urls(self):
        
        
        my_urls = [
            path("login/",self.api_admin_view(self.login),name="login"),
            path("register_user/",self.api_admin_view(self.register_user),name="register_user"),
           

        ]
        return my_urls + super().get_urls()
    
    def register_user(self,request):
        data = json.loads(request.body).get("data")
        
        errors = {}
        errors_count = 0
        if not "first_name" in data :
            errors["first_name"] = ["الاسم الاول مطلوب"]
            errors_count += 1
        if not "last_name" in data :
            errors["last_name"] = ["الاسم الاخير مطلوب"]
            errors_count += 1
        if not "number_phone" in data:
            errors["number_phone"] = ["رقم الهاتف مطلوب"]
            errors_count += 1
        if not "password_register" in data:
            errors["password_register"] = ["ادخل كلمة السر"]
            errors_count += 1

        if errors_count == 0:
            number_phone = data["number_phone"]
            password_register = data["password_register"]
            if len(number_phone) == 9 and number_phone[0] == "7":
                if number_phone[1] == "7" or number_phone[1] == '8' or number_phone[1] == "3" or number_phone[1] == "1" or number_phone[1] == "0":
                    pass
                else:
                    errors["number_phone"] = ["رقم الهاتف غير صحيح"]
                    errors_count += 1
            else:
                errors["number_phone"] = ["رقم الهاتف غير صحيح"]
                errors_count += 1
            if models.Account.objects.filter(username=number_phone).exists():
                errors["number_phone"] = ["رقم الهاتف موجود من قبل"]
                errors_count += 1
            elif not len(password_register) >=7:
                errors["password_register"] = ["يجب أن تكون كلمة المرور 7 محارف على الأقل"]
                errors_count += 1
        if errors_count == 0:
            """print(errors_count,number_phone,auth_models.User.objects.filter(username=number_phone).exists())
            model_user = models.User()
            model_user.username = number_phone
            model_user.password = data["password_register"]
            model_user.first_name=data["first_name"]
            model_user.last_name = data["last_name"]
            model_user.is_active = True
            model_user.is_staff = True
            model_user.save()"""
            models.Account.objects.create_user(
                username = number_phone,
                password=data["password_register"],
                first_name=data["first_name"],
                last_name = data["last_name"],

                is_active = True,
                is_staff = True,

            ).groups.add(auth_models.Group.objects.get(name="almalik_users"))
            user = auth_models.User.objects.get(username=number_phone)
            
            
            return JsonResponse(data={"data":data})
        else:
            errors_content = ""
            for key,value in errors.items():
                errors_content += f"<div class='row'> - {value[0]}</div>"
            return JsonResponse(data={"errors":errors,"detail":errors_content})

api_site = ApiSite(name="api_site")

class ViewSite(AdminSite):

    login_template = "view_site/login.html"
    def index(self, request, extra_context=None):
        extra_context = extra_context or {}

        extra_context.update(
            project_name = "elham_soft"
        )
        return super().index(request, extra_context)
    def each_context(self, request):
        return {
            #"notice_change_list_api_url":reverse(f"api:almalik_noticeuser_changelist"),
            **super().each_context(request)
        }
    def login(self, request, extra_context=None):
        extra_context = extra_context or {}
        


        context = {
            "register_user_url":reverse("api_site:register_user"),
            "login_api_url":reverse("api_site:login"),
            "location_url":reverse("admin:index",current_app=self.name),
        }


        extra_context.update(context)
        is_login = True
        is_soon = True
        is_knowledge = True




        extra_context.update(
            is_login = is_login,
            is_soon = is_soon,
            is_knowledge = is_knowledge,
            

        )
        return super().login(request, extra_context)

view_site = ViewSite(name="view_site")


class AppAdmin(ModelAdmin):
    list_display = ["name","app_dir","datetime_create"]
    def has_change_permission(self, request, obj = None):
        return False
    def has_delete_permission(self, request, obj = None):
        return False
#view_site.register(models.App,AppAdmin)

class AccountAdmin(ModelAdmin):
    list_display = ["messages_list"]
    def changelist_view(self, request, extra_context=None):
        return super().changelist_view(request, extra_context)
    def get_queryset(self, request):
        self.user = request.user

        return super().get_queryset(request)
    def messages_list(self,obj):
        return {
            "userId":obj.id,
            "name":obj.name,
            "path":"",
            "time":"",
            "preview":"",
            "messages":[
                {
                    "fromUserId": chat.to_user.pk,
                    "toUserId": chat.user.pk,
                    "text": chat.text
                } for chat in models.Chat.objects.union(
                    models.Chat.objects.filter(user=obj,to_user=self.user),models.Chat.objects.filter(to_user=obj,user=self.user)
                )
            ]
        }
#view_site.register(models.Account,AccountAdmin)

class AccountApi(ModelApi,AccountAdmin):
    pass
#api_site.register(models.Account,AccountApi)

class ChatAdmin(ModelAdmin):
    def changelist_view(self, request, extra_context=None):
        extra_context = {
            "add_api_url":reverse(f"api_site:{self.opts.app_label}_chat_add"),
        }
        return super().changelist_view(request, extra_context)
#view_site.register(models.Chat,ChatAdmin)

class ChatApi(ModelApi,ChatAdmin):
    pass
#api_site.register(models.Chat,ChatApi)


class NoneAdmin(ModelAdmin):
    def has_module_permission(self, request):
        return False