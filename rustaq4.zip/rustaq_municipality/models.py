
from django.db import models
from django.urls import reverse
from django.contrib.contenttypes import models as contenttype_models
from django.utils.translation import gettext as _
from django.contrib.auth import models as auth_models
from django.contrib import admin
from django.forms import ValidationError, modelform_factory
from django_currentuser.middleware import (
        get_current_user, get_current_authenticated_user)
from jazzmin.options import row,col,format_html,display,date_format
from jazzmin.admin import day_name
class Inspector(auth_models.User):

    class Meta:
        verbose_name = _("مفتش")
        verbose_name_plural = _("المفتشين")
    @property
    def name(self):
        return f"{self.first_name} {self.last_name}"

    def __str__(self):
        return self.name
    _username = None
    def save(self,*args, **kwargs):
        self._username = None
        if not self.pk:
            self.set_password("12345")
            if self._meta.model.objects.count() >= 1:
                self.username = f"h{self._meta.model.objects.last().pk + 1}"
            else:
                self.username = f"h{0 + 1}"
            self._username = self.username
        super().save(*args, **kwargs)
        if self._username and self._username == self.username:
            self.username = f"h{self.pk}"
            self.groups.set(auth_models.Group.objects.filter(name=self._meta.object_name))
            self.save()

    def clean(self):
        message = ""
        if not self.first_name:
            message += "الاسم الأول مطلوب"
        if not self.last_name:
            message += " | " + "الاسم الأخير مطلوب"
        if not message == "":
            raise ValidationError(message)
        return super().clean()
    @property
    @admin.display(description="المجموعات")
    def _groups(self):
        content = ""
        for group in self.groups.all():
            content += row(group.name)
        return format_html(content)


class Activity(models.Model):
    name = models.CharField(_("اسم النشاط"), max_length=200,unique=True)
    code = models.PositiveIntegerField(_("code"),unique=True)
    class Meta:
        verbose_name = _("Activity")
        verbose_name_plural = _("Activitys")

    def __str__(self):
        return self.name

class ActivityType(models.Model):
    activity = models.ForeignKey(Activity, verbose_name=_("activity"), on_delete=models.CASCADE,null=True)
    name = models.CharField(_("نوع النشاط"), max_length=500,unique=True)
    number = models.PositiveIntegerField(_("رقم النشاط"),null=True,blank=True,unique=True)
    class Meta:
        verbose_name = _("نشاط تجاري")
        verbose_name_plural = _("أنواع الأنشطة التجارية")

    def __str__(self):
        return f"{self.name}  ||  {self.number}"


class Village(models.Model):
    name = models.CharField(_("اسم القرية"), max_length=500,unique=True)

    class Meta:
        verbose_name = _("قرية")
        verbose_name_plural = _("القرى")

    def __str__(self):
        return self.name

class Address(models.Model):
    name = models.CharField(_("العنوان"), max_length=500,unique=True)

    class Meta:
        verbose_name = _("عنوان")
        verbose_name_plural = _("العناوين")

    def __str__(self):
        return self.name


class TradeName(models.Model):
    name = models.CharField(_("الاسم التجاري"), max_length=500,unique=True)
    
    class Meta:
        verbose_name = _("TradeName")
        verbose_name_plural = _("TradeNames")

    def __str__(self):
        return self.name

class TradeNumber(models.Model):
    number = models.PositiveIntegerField(_("number"),unique=True)
    
    class Meta:
        verbose_name = _("TradeNumber")
        verbose_name_plural = _("TradeNumbers")

    def __str__(self):
        return str(self.number)


class Facility(models.Model):
    tradename = models.ForeignKey(TradeName, verbose_name=_("الاسم التجاري للمنشأة"), on_delete=models.CASCADE)
    tradenumber = models.ForeignKey(TradeNumber, verbose_name=_("رقم السجل التجاري"), on_delete=models.CASCADE)
    activitytypes = models.ManyToManyField(ActivityType, verbose_name=_("النشاط التجاري || رقم النشاط التجاري"))
    facility_CATEGORES = [
        ("عالي الخطورة","عالي الخطورة"),
        ("متوسط الخطورة","متوسط الخطورة")
    ]
    facilitycategore = models.CharField(_("تصنيف المنشأة"), max_length=500,choices=facility_CATEGORES)
    address = models.ForeignKey(Address, verbose_name=_("العنوان"), on_delete=models.CASCADE)
    village = models.ForeignKey(Village, verbose_name=_("القرية"), on_delete=models.CASCADE,null=True)
    location = models.URLField(_("الموقع في قوقل"), max_length=200,null=True,blank=True)
    notice = models.TextField(_("ملاحظات"),null=True,blank=True)

    @property
    @admin.display(description="تاريخ آخر زيارة")
    def date_last_visit(self):
        if self.visits.exists():
            return self.visits.last().date
        return "لم تتم زيارتها"

    @property
    def visits(self):
        return Visit.objects.filter(facility=self)
    
    @property
    @admin.display(description="نوع النشاط التجاري")
    def _activitytypes(self):
        content = ""
        for activity_type in self.activitytypes.all():
            content += f"""{activity_type.name} و """
        return content[:-3]
    
    @property
    @admin.display(description="الموقع في الخريطة")
    def _location(self):
        if self.location:
            return format_html(f"""<a href="{self.location}" >عرض الموقع</a>""")
        return ""
    
    class Meta:
        verbose_name = _("منشأة")
        verbose_name_plural = _("قاعدة البيانات")

    def __str__(self):
        return f"{self.tradename} || {self.tradenumber}"




class Licensing(models.Model):
    date = models.DateField(_("التاريخ"), auto_now=False, auto_now_add=False)
    day_name = models.CharField(_("اليوم"), max_length=500,null=True,blank=True)
    facility = models.ForeignKey(Facility, verbose_name=_("الاسم التجاري للمنشأة  ||  رقم السجل التجاري للمنشأة"), on_delete=models.CASCADE)
    facility_tradename = models.CharField(_("الاسم التجاري للمنشأة"), max_length=500,null=True,blank=True)
    facility_tradenumber = models.CharField(_("رقم السجل التجاري"), max_length=500,null=True,blank=True)
    facility_activitytypes = models.CharField(_("نوع النشاط التجاري"), max_length=500,null=True,blank=True)
    facility_facilitycategore = models.CharField(_("تصنيف النشاط التجاري"), max_length=500,null=True,blank=True)
    facility_address = models.CharField(_("العنوان"), max_length=500,null=True,blank=True)
    datetime_add = models.DateTimeField(_("date time add"), auto_now=False, auto_now_add=True)
    datetime_change = models.DateTimeField(_("date time change"), auto_now=True, auto_now_add=False)
    user = models.ForeignKey(auth_models.User, verbose_name=_("المستخدم"), on_delete=models.CASCADE,editable=False)
    PROCEDURES = [
        ("توجيه","توجيه"),
        ("إنذار بمخالفة","إنذار بمخالفة"),
        ("مخالفة","مخالفة"),
        ("إتلاف","إتلاف"),
        ("مخالفة مع إتلاف","مخالفة مع إتلاف"),
        ("تنبيه","تنبيه"),
        ("مغلق أثناء الزيارة","مغلق أثناء الزيارة"),
        ("غلق المنشأة","غلق المنشأة"),
    ]
    procedure = models.CharField(_("الإجراء"), max_length=500,choices=PROCEDURES)
    ORDERSTATUS = [
        ("مكتمل","مكتمل"),
        ("غير مكتمل","غير مكتمل"),
    ]
    orderstatu = models.CharField(_("حالة الطلب"), max_length=500,choices=ORDERSTATUS)
    LIMITATION_TYPES = [
        ("Visit","زيارة يومية"),
        ("Violation","مخالفة صحية"),
        ("Complaint","شكوى وبلاغ"),
        ("Damage","تعامل مع مواد غذائية (إتلاف)"),
        ("FoodSample","عينات أغذية"),
        ("WaterSample","عينات مياه"),
    ]
    limitation_type = models.CharField(_("نوع القيد"), max_length=500,choices=LIMITATION_TYPES,editable=False)
    @property
    @admin.display(description="رقم التقرير")
    def _id(self):
        return self.pk
    @property
    @admin.display(description="الاسم التجاري للمنشأة")
    def _facility_tradename(self):
        return self.facility.tradename.name
    @property
    @admin.display(description="رقم السجل التجاري")
    def _facility_tradenumber(self):
        return self.facility_tradenumber

    @property
    @admin.display(description="نوع النشاط التجاري")
    def _facility_activitytypes(self):
        return self.facility._activitytypes
    @property
    @admin.display(description="تصنيف النشاط التجاري")
    def _facility_facilitycategore(self):
        return self.facility.facilitycategore
    @property
    @admin.display(description="العنوان")
    def _facility_address(self):
        return self.facility.address
    @property
    @admin.display(description="القرية")
    def _facility_village(self):
        return self.facility.village.name
    


    class Meta:
        verbose_name = _("إستمارة")
        verbose_name_plural = _("استمارات قسم الرقابة والتراخيص الغذائية")

    def __str__(self):
        return f"{self.facility.tradename} | {self.date} | {self.procedure}"

    def save(self,*args, **kwargs):
        #print(self.limitation_type,_models.get(model="Visit",app_label="rustaq_municipality"))
        if not self.limitation_type:
            self.limitation_type = self._meta.model._meta.object_name
            if not getattr(self,"user_id"):
                self.user = get_current_user()
        super().save(*args, **kwargs)
    @property
    @admin.display(description="نوع القيد")
    def _limitation_type(self):
        for key, value in self.LIMITATION_TYPES:
            if key == self.limitation_type:
                return value
        return "-"




class Visit(Licensing):
    detail = models.TextField(_("وصف الزيارة والإجراء"))
    notice = models.TextField(_("الملاحظات"))
    file = models.FileField(_("مستند"), upload_to="rustaq_municipality/visit/file", max_length=100,null=True,blank=True)

    class Meta:
        verbose_name = _("زيارة يومية")
        verbose_name_plural = _("الزيارات اليومية")


class Violation(Licensing):
    number = models.PositiveBigIntegerField(_("رقم المخالفة في النظام"))
    amount_fine = models.PositiveSmallIntegerField(_("مقدار الغرامة المالية"))
    file = models.FileField(_("مستند"), upload_to="rustaq_municipality/Violation/file", max_length=100,null=True,blank=True)
    item = models.CharField(_("بند المخالفة"), max_length=500)
    detail = models.TextField(_("وصف المخالفة والإجراء"))
    notice = models.TextField(_("الملاحظات والإجراءات المتخذة"))

    class Meta:
        verbose_name = _("مخالفة صحية")
        verbose_name_plural = _("المخالفات الصحية")


class Complaint(Licensing):
    COMPLAINT_TYPES = [
        ("بلاغ","بلاغ"),
        ("شكوى","شكوى"),
        ("تعميم","تعميم"),
        ("أخرى","أخرى"),
    ]
    complaint_type = models.CharField(_("نوع البلاغ الوارد"), max_length=500,choices=COMPLAINT_TYPES)
    complaint_side = models.CharField(_("مصدر/جهة مقدم الشكوى/البلاغ/التعميم"), max_length=500)
    phone = models.PositiveIntegerField(_("رقم الهاتف(ان وجد)"),null=True,blank=True)
    detail = models.TextField(_("وصف الشكوى/البلاغ/التعميم"))
    detail_procedure = models.TextField(_("وصف الإجراء"))
    date_end = models.DateField(_("تاريخ الأنتهاء"), auto_now=False, auto_now_add=False,null=True,blank=True)
    file = models.FileField(_("مستند"), upload_to="rustaq_municipality/Violation/file", max_length=100,null=True,blank=True)
    notice = models.TextField(_("الملاحظات"))

    class Meta:
        verbose_name = _("شكوى وبلاغ")
        verbose_name_plural = _("الشكاوى والبلاغات")




class Damage(Licensing):
    damage_because = models.CharField(_("سبب الإتلاف"), max_length=500)
    file = models.FileField(_("إرفاق ملف"), upload_to="rustaq_municipality/Damage/file", max_length=100,null=True,blank=True)
    notice = models.TextField(_("الملاحظات"))

    class Meta:
        verbose_name = _("مادة غذائية متلفة")
        verbose_name_plural = _("التعامل مع المواد الغذائية أو الإتلافات")

class DamageMaterial(models.Model):
    damage = models.ForeignKey(Damage, verbose_name=_("الإتلاف"), on_delete=models.CASCADE)
    material_type = models.CharField(_("نوع المادة الغذائية"), max_length=500)
    because = models.CharField(_("سبب الإتلاف"), max_length=100)
    total = models.PositiveSmallIntegerField(_("كمية المادة المتلفة (كجم)"))
    setting_number = models.PositiveSmallIntegerField(_("عدد الضبط"))
    release_number = models.PositiveSmallIntegerField(_("عدد الإفراج"))
    damage_number = models.PositiveSmallIntegerField(_("عدد الإتلاف"))


    class Meta:
        verbose_name = _("بيانات مادة غذائية")
        verbose_name_plural = _("بيانات المواد الغذائية")

    def __str__(self):
        return f"{self.material_type} | {self.because}"

    @property
    @admin.display(description="رقم الإتلاف")
    def _id(self):
        return self.pk

class FoodSample(Licensing):
    notice = models.TextField(_("الملاحظات"))

    class Meta:
        verbose_name = _("عينة غذائية")
        verbose_name_plural = _("عينات الأغذية")

class FoodSampleMaterial(models.Model):
    foodsample = models.ForeignKey(FoodSample, verbose_name=_("عينة الأغذية"), on_delete=models.CASCADE)
    foodsamplematerial_type = models.CharField(_("نوع المادة الغذائية"), max_length=200)
    foodsample_number = models.PositiveSmallIntegerField(_("رقم العينة"))
    product_name = models.CharField(_("اسم المنتج الغذائي"), max_length=500)
    number_units = models.PositiveSmallIntegerField(_("عدد الوحدات"))
    date_withdrawal = models.DateField(_("تاريخ سحب العينة"), auto_now=False, auto_now_add=False)
    date_submit = models.DateField(_("تاريخ إرسال العينة"), auto_now=False, auto_now_add=False)
    material_because = models.CharField(_("نوع/سبب سحب العينة"), max_length=500)
    result = models.CharField(_("نتيجة العينة"), max_length=5000)

    class Meta:
        verbose_name = _("بيانات عينة غذائية")
        verbose_name_plural = _("بيانات عينات الأغذية")

    def __str__(self):
        return f"{self.foodsamplematerial_type} | {self.result}"



class WaterSample(Licensing):
    notice = models.TextField(_("الملاحظات"))

    class Meta:
        verbose_name = _("عينة مياه")
        verbose_name_plural = _("عينات المياه")

class WaterSampleMaterial(models.Model):
    watersample = models.ForeignKey(WaterSample, verbose_name=_("عينة المياة"), on_delete=models.CASCADE)
    WATERSAMPLEMATERIAL_TYPES = [
        ("آبار","آبار"),
        ("شبكات المياه","شبكات المياه"),
        ("المدارس","المدارس"),
        ("مساجد","مساجد"),
        ("المطاعم والمقاهي","المطاعم والمقاهي"),
        ("المياه المعدنية","المياه المعدنية"),
        ("سيارات نقل المياه","سيارات نقل المياه"),
        ("أخرى","أخرى"),
    ]
    watersamplematerial_type = models.CharField(_("نوع عينة المياه"), max_length=500)
    watersample_number = models.PositiveSmallIntegerField(_("رقم العينة"))
    brand_name = models.CharField(_("اسم العلامة التجارية"), max_length=500)
    capacity = models.PositiveSmallIntegerField(_("سعة العينة"))
    number_units = models.PositiveSmallIntegerField(_("عدد الوحدات"))
    date_withdrawal = models.DateField(_("تاريخ سحب العينة"), auto_now=False, auto_now_add=False)
    date_submit = models.DateField(_("تاريخ إرسال العينة"), auto_now=False, auto_now_add=False)
    material_because = models.CharField(_("نوع/سبب سحب العينة"), max_length=500)
    result = models.CharField(_("نتيجة العينة"), max_length=5000,null=True,blank=True)


    class Meta:
        verbose_name = _("بيانات عينة مياه")
        verbose_name_plural = _("بيانات عينات المياه")

    def __str__(self):
        return f"{self.watersamplematerial_type} | {self.result}"

class Initiative(models.Model):
    date = models.DateField(_("التاريخ"), auto_now=False, auto_now_add=False)
    day_name = models.CharField(_("اليوم"), max_length=500,null=True,blank=True)
    address = models.CharField(_("عنوان المبادرة"), max_length=5000)
    initiative_type = models.CharField(_("نوع المبادرة"), max_length=500)
    detail = models.TextField(_("وصف المبادرة"))
    initiative_side = models.CharField(_("جهة تنفيذ المبادرة"), max_length=500)
    initiative_side_phone = models.PositiveBigIntegerField(_("رقم هاتف جهة التنفيذ"))
    qaim_name = models.CharField(_("اسم القائم على تنفيذ المبادرة"), max_length=500)
    file = models.FileField(_("مستند"), upload_to="rustaq_municipality/Initiative/file", max_length=100,null=True,blank=True)
    ORDERSTATUS = [
        ("مكتمل","مكتمل"),
        ("غير مكتمل","غير مكتمل"),
    ]
    orderstatu = models.CharField(_("حالة الطلب"), max_length=500,choices=ORDERSTATUS)

    notice = models.TextField(_("الملاحظات"))

    class Meta:
        verbose_name = _("توعية ومبادرة")
        verbose_name_plural = _("التوعية والمبادرات")

    @property
    @admin.display(description="اليوم")
    def _day_name(self):
        return day_name(self.date)


class ButcheryOpera(models.Model):

    date = models.DateField(_("التاريخ"), auto_now=False, auto_now_add=False)
    beneficial = models.CharField(_("المستفيد"), max_length=500)
    user = models.ForeignKey(auth_models.User, verbose_name=_("المستخدم"), on_delete=models.CASCADE,editable=False)

    salughter_beautys = models.PositiveSmallIntegerField(_("جمال"),blank=True)
    salughter_cows = models.PositiveSmallIntegerField(_("أبقار"),blank=True)
    salughter_sheeps = models.PositiveSmallIntegerField(_("خراف"),blank=True)
    salughter_livestocks = models.PositiveSmallIntegerField(_("أغنام"),blank=True)
    salughter_total = models.PositiveIntegerField(_("إجمالي المذبوحات"),editable=False)

    damagetotal_beautys = models.PositiveSmallIntegerField(_("جمال"),blank=True)
    damagetotal_cows = models.PositiveSmallIntegerField(_("أبقار"),blank=True)
    damagetotal_sheeps = models.PositiveSmallIntegerField(_("خراف"),blank=True)
    damagetotal_livestocks = models.PositiveSmallIntegerField(_("أغنام"),blank=True)
    damagetotal_total = models.PositiveIntegerField(_("إجمالي الإتلاف الكلي"),editable=False)

    damagepartial_beautys = models.PositiveSmallIntegerField(_("جمال"),blank=True)
    damagepartial_cows = models.PositiveSmallIntegerField(_("أبقار"),blank=True)
    damagepartial_sheeps = models.PositiveSmallIntegerField(_("خراف"),blank=True)
    damagepartial_livestocks = models.PositiveSmallIntegerField(_("أغنام"),blank=True)
    damagepartial_total = models.PositiveIntegerField(_("إجمالي الإتلاف الجزئي"),editable=False)


    class Meta:
        verbose_name = _("قيد")
        verbose_name_plural = _("مسلخ دائرة البلدية بالرستاق")
    @property
    @admin.display(description="التاريخ")
    def _date(self):
        return date_format(self.date)
    def __str__(self):
        return f"{self.date}|{self.beneficial}"

    def save(self,*args, **kwargs):

        if not getattr(self,"user_id"):
            self.user = get_current_user()

        if self.salughter_beautys == None:
            self.salughter_beautys = 0
        if self.salughter_cows == None :
            self.salughter_cows = 0
        if self.salughter_sheeps == None :
            self.salughter_sheeps = 0
        if self.salughter_livestocks == None :
            self.salughter_livestocks = 0

        if self.damagetotal_beautys == None:
            self.damagetotal_beautys = 0
        if self.damagetotal_cows == None :
            self.damagetotal_cows = 0
        if self.damagetotal_sheeps == None :
            self.damagetotal_sheeps = 0
        if self.damagetotal_livestocks == None :
            self.damagetotal_livestocks = 0

        if self.damagepartial_beautys == None:
            self.damagepartial_beautys = 0
        if self.damagepartial_cows == None :
            self.damagepartial_cows = 0
        if self.damagepartial_sheeps == None :
            self.damagepartial_sheeps = 0
        if self.damagepartial_livestocks == None :
            self.damagepartial_livestocks = 0


        self.salughter_total = self.salughter_beautys + self.salughter_cows + self.salughter_sheeps + self.salughter_livestocks
        self.damagepartial_total = self.damagepartial_beautys + self.damagepartial_cows + self.damagepartial_sheeps + self.damagepartial_livestocks
        self.damagetotal_total = self.damagetotal_beautys + self.damagetotal_cows + self.damagetotal_sheeps + self.damagetotal_livestocks
        super().save(*args, **kwargs)



    @property
    @admin.display(description="إجمالي الإتلاف")
    def damage_total(self):
        return self.damagetotal_total + self.damagepartial_total






class DayR(models.Model):
    date_gte = models.DateField(_("من تاريخ"), auto_now=False, auto_now_add=False)
    date_lte = models.DateField(_("حتى تاريخ"), auto_now=False, auto_now_add=False)

    class Meta:
        verbose_name = _("تقرير يومي")
        verbose_name_plural = _("التقرير اليومي")

class MonthR(models.Model):
    date_gte = models.DateField(_("من تاريخ"), auto_now=False, auto_now_add=False)
    date_lte = models.DateField(_("حتى تاريخ"), auto_now=False, auto_now_add=False)

    class Meta:
        verbose_name = _("تقرير شهري")
        verbose_name_plural = _("التقرير الشهري")

class YearR(models.Model):
    date_gte = models.DateField(_("من تاريخ"), auto_now=False, auto_now_add=False)
    date_lte = models.DateField(_("حتى تاريخ"), auto_now=False, auto_now_add=False)

    class Meta:
        verbose_name = _("تقرير سنوي")
        verbose_name_plural = _("التقرير السنوي")








