from django.test import TestCase
from jazzmin.admin import *

# Create your tests here.
import pandas as pd
from . import models

def activity_emport():
    # قراءة ملف Excel إلى DataFrame
    df = pd.read_excel('activitys.xlsx')
    for index in df.index:
        id = df[df.columns[0]][index]
        tradename = df[df.columns[1]][index]
        activitytypes = df[df.columns[2]][index]
        tradenumber = df[df.columns[3]][index]
        address = df[df.columns[4]][index]
        facilitycategore = df[df.columns[5]][index]
        
        models.Facility.objects.get_or_create(
            id=int(id),
            tradename=models.TradeName.objects.get_or_create(
                name=tradename,
            )[0],
            tradenumber=models.TradeNumber.objects.get_or_create(
                number=int(tradenumber),
            )[0],
            address=models.Address.objects.get_or_create(
                name=address,
            )[0],
            facilitycategore=facilitycategore,
        )[0].activitytypes.add(
            models.ActivityType.objects.get_or_create(
                name=activitytypes,
                
                #number=112233,
            )[0],
        )
        print(id)