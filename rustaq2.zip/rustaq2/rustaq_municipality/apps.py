from django.apps import AppConfig


class RustaqMunicipalityConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'rustaq_municipality'
    verbose_name = "بلدية الرستاق"
    def ready(self):
        from django.contrib.auth import models as auth_models

        auth_models.Group.objects.get_or_create(
            name="Inspector",
        )[0].permissions.set(auth_models.Permission.objects.filter(codename__in=[
            "view_licensing","add_","change_","delete_",
            "view_","add_visit","change_","delete_",
            "view_","add_violation","change_","delete_",
            "view_","add_complaint","change_","delete_",
            "view_","add_damage","change_","delete_",
            "view_damagematerial","add_damagematerial","change_","delete_",
            "view_","add_foodsample","change_","delete_",
            "view_foodSamplematerial","add_foodSamplematerial","change_","delete_",
            "view_","add_watersample","change_","delete_",
            "view_watersamplematerial","add_watersamplematerial","change_","delete_",
            "view_initiative","add_initiative","change_","delete_",
            "view_","add_","change_","delete_",
            "view_","add_","change_","delete_",
            "view_","add_","change_","delete_",
            "view_","add_","change_","delete_",
            "view_","add_","change_","delete_",
            "view_","add_","change_","delete_",
            "view_","add_","change_","delete_",

            ]))
        
        auth_models.Group.objects.get_or_create(
            name="Management",
        )[0].permissions.set(auth_models.Permission.objects.filter(codename__in=[
            "view_licensing","add_","change_","delete_",
            "view_","add_visit","change_","delete_",
            "view_","add_violation","change_","delete_",
            "view_","add_complaint","change_","delete_",
            "view_","add_damage","change_","delete_",
            "view_damagematerial","add_damagematerial","change_","delete_",
            "view_","add_foodsample","change_","delete_",
            "view_foodSamplematerial","add_foodSamplematerial","change_","delete_",
            "view_","add_watersample","change_","delete_",
            "view_watersamplematerial","add_watersamplematerial","change_","delete_",
            "view_initiative","add_initiative","change_","delete_",
            "view_butcheryopera","add_butcheryopera","change_","delete_",
            "view_butcheryoperasalughter","add_butcheryoperasalughter","change_","delete_",
            "view_butcheryoperatotaldamage","add_butcheryoperatotaldamage","change_","delete_",
            "view_butcheryoperapartialdamage","add_butcheryoperapartialdamage","change_","delete_",
            "view_dayr","add_dayr","change_","delete_",
            "view_monthr","add_monthr","change_","delete_",
            "view_yearr","add_yearr","change_","delete_",
            "view_inspector","add_inspector","change_","delete_",
            "view_activity","add_activity","change_","delete_",
            "view_activitytype","add_activitytype","change_","delete_",
            "view_activitycategore","add_activitycategore","change_","delete_",
            "view_village","add_village","change_","delete_",
            "view_group","add_","change_","delete_",

            ]))
        
        auth_models.Group.objects.get_or_create(
            name="Butchery",
        )[0].permissions.set(auth_models.Permission.objects.filter(codename__in=[
            "view_butcheryopera","add_butcheryopera","change_","delete_",
            "view_butcheryoperasalughter","add_butcheryoperasalughter","change_","delete_",
            "view_butcheryoperatotaldamage","add_butcheryoperatotaldamage","change_","delete_",
            "view_butcheryoperapartialdamage","add_butcheryoperapartialdamage","change_","delete_",
            "view_","add_","change_","delete_",
            "view_","add_","change_","delete_",
            "view_","add_","change_","delete_",
            "view_","add_","change_","delete_",
            "view_","add_","change_","delete_",
            "view_","add_","change_","delete_",
            "view_","add_","change_","delete_",
            "view_","add_","change_","delete_",
            "view_","add_","change_","delete_",
            "view_","add_","change_","delete_",
            "view_","add_","change_","delete_",

            ]))
        if not auth_models.User.objects.filter(username="manager").exists():
            auth_models.User.objects.create_user(
                username="manager",
                password="12345",
            ).groups.set(
                auth_models.Group.objects.filter(name="Management")
            )
        if not auth_models.User.objects.filter(username="admin").exists():
            auth_models.User.objects.create_superuser(
                username="admin",
                password="1234567",
            )
        super().ready()

    