
from django.db import models
from django.urls import reverse
from django.contrib.contenttypes import models as contenttype_models
from django.utils.translation import gettext as _
from django.contrib.auth import models as auth_models
from django.contrib import admin
from django.forms import ValidationError
from django_currentuser.middleware import (
        get_current_user, get_current_authenticated_user)
from jazzmin.options import row,col,format_html,display
class Inspector(auth_models.User):
    
    class Meta:
        verbose_name = _("مفتش")
        verbose_name_plural = _("المفتشين")
    @property
    def name(self):
        return f"{self.first_name} {self.last_name}"
    
    def __str__(self):
        return self.name
    _username = None
    def save(self,*args, **kwargs):
        self._username = None
        if not self.pk:
            self.set_password("12345")
            if self._meta.model.objects.count() >= 1:
                self.username = f"h{self._meta.model.objects.last().pk + 1}"
            else:
                self.username = f"h{0 + 1}"
            self._username = self.username
        super().save(*args, **kwargs)
        if self._username and self._username == self.username:
            self.username = f"h{self.pk}"
            self.groups.set(auth_models.Group.objects.filter(name=self._meta.object_name))
            self.save()
    
    def clean(self):
        message = ""
        if not self.first_name:
            message += "الإسم الأول مطلوب"
        if not self.last_name:
            message += " | " + "الإسم الأخير مطلوب"
        if not message == "":
            raise ValidationError(message)
        return super().clean()
    @property
    @admin.display(description="المجموعات")
    def _groups(self):
        content = ""
        for group in self.groups.all():
            content += row(group.name)
        return format_html(content)


class ActivityType(models.Model):
    name = models.CharField(_("اسم النشاط"), max_length=50)
    number = models.PositiveIntegerField(_("رقم النشاط"))
    class Meta:
        verbose_name = _("نشاط تجاري")
        verbose_name_plural = _("أنواع الأنشطة التجارية")

    def __str__(self):
        return f"{self.name}  ||  {self.number}"


class Village(models.Model):
    name = models.CharField(_("اسم القرية"), max_length=50,unique=True)
    
    class Meta:
        verbose_name = _("قرية")
        verbose_name_plural = _("القرى")

    def __str__(self):
        return self.name


class Activity(models.Model):
    name = models.CharField(_("الإسم التجاري للمنشأة"), max_length=50,unique=True)
    number_register = models.PositiveBigIntegerField(_("رقم السجل التجاري"),unique=True)
    activitytypes = models.ManyToManyField(ActivityType, verbose_name=_("النشاط التجاري || رقم النشاط التجاري"))
    ACTIVITY_CATEGORES = [
        ("عالي الخطورة","عالي الخطورة"),
        ("متوسط الخطورة","متوسط الخطورة")
    ]
    activitycategore = models.CharField(_("تصنيف المنشأة"), max_length=50,choices=ACTIVITY_CATEGORES)
    address = models.CharField(_("العنوان"), max_length=500)
    village = models.ForeignKey(Village, verbose_name=_("القرية"), on_delete=models.CASCADE)
    notice = models.TextField(_("ملاحظات"),null=True,blank=True)

    @property
    @admin.display(description="تاريخ آخر زيارة")
    def date_last_visit(self):
        if self.visits.exists():
            return self.visits.last().date
        return "لم تتم زيارتها"

    @property
    def visits(self):
        return Visit.objects.filter(activity_name=self)
    @property
    def _activitytypes(self):
        content = ""
        for activity_type in self.activitytypes.all():
            content += f"""{row(activity_type.name)}"""
        return Visit.objects.filter(activity_name=self)
    class Meta:
        verbose_name = _("منشأة")
        verbose_name_plural = _("قاعدة البيانات")

    def __str__(self):
        return f"{self.name} || {self.number_register}"


  

class Licensing(models.Model):
    date = models.DateField(_("التاريخ"), auto_now=False, auto_now_add=False)
    day_name = models.CharField(_("اليوم"), max_length=50,null=True,blank=True)
    activity = models.ForeignKey(Activity, verbose_name=_("الأسم التجاري للمنشأة  ||  رقم السجل التجاري للمنشأة"), on_delete=models.CASCADE)
    activity_name = models.CharField(_("الإسم التجاري للمنشأة"), max_length=50,null=True,blank=True)
    activity_number_register = models.CharField(_("رقم السجل التجاري"), max_length=50,null=True,blank=True)
    activity_type = models.CharField(_("نوع النشاط التجاري"), max_length=50,null=True,blank=True)
    activity_categore = models.CharField(_("تصنيف النشاط التجاري"), max_length=50,null=True,blank=True)
    activity_address = models.CharField(_("العنوان"), max_length=50,null=True,blank=True)
    inspector = models.ForeignKey(Inspector, verbose_name=_("المفتش"), on_delete=models.CASCADE,editable=False,null=True,blank=True)
    PROCEDURES = [
        ("توجيه","توجيه"),
        ("إنذار بمخالفة","إنذار بمخالفة"),
        ("مخالفة","مخالفة"),
        ("إتلاف","إتلاف"),
        ("مخالفة مع إتلاف","مخالفة مع إتلاف"),
        ("تنبيه","تنبيه"),
        ("مغلق أثناء الزيارة","مغلق أثناء الزيارة"),
        ("غلق المنشأة","غلق المنشأة"),
    ]
    procedure = models.CharField(_("الإجراء"), max_length=50,choices=PROCEDURES)
    ORDERSTATUS = [
        ("مكتمل","مكتمل"),
        ("غير مكتمل","غير مكتمل"),
    ]
    orderstatu = models.CharField(_("حالة الطلب"), max_length=50,choices=ORDERSTATUS)
    LIMITATION_TYPES = [
        ("Visit","زيارة يومية"),
        ("Violation","مخالفة صحية"),
        ("Complaint","شكوى وبلاغ"),
        ("Damage","تعامل مع مواد غذائية (إتلاف)"),
        ("FoodSample","عينات أغذية"),
        ("WaterSample","عينات مياه"),
    ]
    limitation_type = models.CharField(_("نوع القيد"), max_length=50,choices=LIMITATION_TYPES,editable=False)
    @property
    @admin.display(description="رقم التقرير")
    def _id(self):
        return self.pk
    @property
    @admin.display(description="الإسم التجاري للمنشأة")
    def _activity_name(self):
        return self.activity.name
    @property
    @admin.display(description="رقم السجل التجاري")
    def _activity_number_register(self):
        return self.activity.number_register
    @property
    @admin.display(description="نوع النشاط التجاري")
    def _activity_activitytype(self):
        return self.activity.activitytype
    @property
    @admin.display(description="تصنيف النشاط التجاري")
    def _activity_activitycategore(self):
        return self.activity.activitycategore
    @property
    @admin.display(description="العنوان")
    def _activity_address(self):
        return self.activity.address
    @property
    @admin.display(description="القرية")
    def _activity_village(self):
        return self.activity.village
    
    class Meta:
        verbose_name = _("إستمارة")
        verbose_name_plural = _("إستمارات قسم الرقابة والتراخيص الغذائية")

    def __str__(self):
        return f"{self.activity.name} | {self.date} | {self.procedure}"

    def save(self,*args, **kwargs):
        #print(self.limitation_type,_models.get(model="Visit",app_label="rustaq_municipality"))
        if not self.limitation_type:
            self.limitation_type = self._meta.model._meta.object_name
            if not getattr(self,"inspector_id"):
                inspector = Inspector.objects.filter(username=get_current_user().username)
                if inspector.exists():
                    self.inspector = Inspector.objects.get(username=get_current_user().username)
        super().save(*args, **kwargs)
        
    @property
    @admin.display(description="نوع القيد")
    def _limitation_type(self):
        for key, value in self.LIMITATION_TYPES:
            if key == self.limitation_type:
                return value
        return "-"
   

   

class Visit(Licensing):
    detail = models.TextField(_("وصف الزيارة والإجراء"))
    notice = models.TextField(_("الملاحظات"))
    file = models.FileField(_("مستند"), upload_to="rustaq_municipality/visit/file", max_length=100,null=True,blank=True)

    class Meta:
        verbose_name = _("زيارة يومية")
        verbose_name_plural = _("الزيارات اليومية")


class Violation(Licensing):
    number = models.PositiveBigIntegerField(_("رقم المخالفة في النظام"))
    amount_fine = models.PositiveSmallIntegerField(_("مقدار الغرامة المالية"))
    file = models.FileField(_("مستند"), upload_to="rustaq_municipality/Violation/file", max_length=100,null=True,blank=True)
    item = models.CharField(_("بند المخالفة"), max_length=50)
    detail = models.TextField(_("وصف المخالفة والإجراء"))
    notice = models.TextField(_("الملاحظات والإجراءات المتخذة"))

    class Meta:
        verbose_name = _("مخالفة صحية")
        verbose_name_plural = _("المخالفات الصحية")


class Complaint(Licensing):
    COMPLAINT_TYPES = [
        ("بلاغ","بلاغ"),
        ("شكوى","شكوى"),
        ("تعميم","تعميم"),
        ("أخرى","أخرى"),
    ]
    complaint_type = models.CharField(_("نوع البلاغ الوارد"), max_length=50,choices=COMPLAINT_TYPES)
    complaint_side = models.CharField(_("مصدر/جهة مقدم الشكوى/البلاغ/التعميم"), max_length=50)
    phone = models.PositiveIntegerField(_("رقم الهاتف(ان وجد)"),null=True,blank=True)
    detail = models.TextField(_("وصف الشكوى/البلاغ/التعميم"))
    detail_procedure = models.TextField(_("وصف الجرا"))
    date_end = models.DateField(_("تاريخ الأنتهاء"), auto_now=False, auto_now_add=False)
    file = models.FileField(_("مستند"), upload_to="rustaq_municipality/Violation/file", max_length=100,null=True,blank=True)
    notice = models.TextField(_("الملاحظات"))

    class Meta:
        verbose_name = _("شكوى وبلاغ")
        verbose_name_plural = _("السكاوى والبلاغات")




class Damage(Licensing):
    damage_because = models.CharField(_("سبب الإتلاف"), max_length=50)
    file = models.FileField(_("إرفاق ملف"), upload_to="rustaq_municipality/Damage/file", max_length=100,null=True,blank=True)
    notice = models.TextField(_("الملاحظات"))

    class Meta:
        verbose_name = _("تعامل مع مواد غذائية أو إتلاف")
        verbose_name_plural = _("لتعامل مع المواد الغذائة أو الإتلافات")

class DamageMaterial(models.Model):
    damage = models.ForeignKey(Damage, verbose_name=_("الإتلاف"), on_delete=models.CASCADE)
    material_type = models.CharField(_("نوع المادة الغذائية"), max_length=50)
    because = models.CharField(_("سبب الإتلاف"), max_length=100)
    total = models.PositiveSmallIntegerField(_("كمية المادة المتلفة (كجم)"))
    setting_number = models.PositiveSmallIntegerField(_("عدد الضبط"))
    release_number = models.PositiveSmallIntegerField(_("عدد الإفراج"))
    damage_number = models.PositiveSmallIntegerField(_("عدد الإتلاف"))


    class Meta:
        verbose_name = _("بيانات مادة غذائية")
        verbose_name_plural = _("بيانات المواد الغذائية")

    def __str__(self):
        return f"{self.material_type} | {self.because}"
    
    @property
    @admin.display(description="رقم الإتلاف")
    def _id(self):
        return self.pk
 
class FoodSample(Licensing):
    notice = models.TextField(_("الملاحظات"))

    class Meta:
        verbose_name = _("عينة غذاء")
        verbose_name_plural = _("عينات الأغذية")

class FoodSampleMaterial(models.Model):
    foodsample = models.ForeignKey(FoodSample, verbose_name=_("عينة الأغذية"), on_delete=models.CASCADE)
    foodsamplematerial_type = models.CharField(_("نوع المادة الغذائية"), max_length=200)
    foodsample_number = models.PositiveSmallIntegerField(_("رقم العينة"))
    product_name = models.CharField(_("إسم المنتج الغذائي"), max_length=50)
    number_units = models.PositiveSmallIntegerField(_("عدد الوحدات"))
    date_withdrawal = models.DateField(_("تاريخ سحب العينة"), auto_now=False, auto_now_add=False)
    date_submit = models.DateField(_("تاريخ إرسال العينة"), auto_now=False, auto_now_add=False)
    material_because = models.CharField(_("نوع/سبب سحب العينة"), max_length=50)
    result = models.CharField(_("نتيجة العينة"), max_length=500)
    
    class Meta:
        verbose_name = _("بيانات عينة غذاء")
        verbose_name_plural = _("بيانات عينات الأغذية")

    def __str__(self):
        return f"{self.foodsamplematerial_type} | {self.result}"

  

class WaterSample(Licensing):
    notice = models.TextField(_("الملاحظات"))

    class Meta:
        verbose_name = _("عينة مياه")
        verbose_name_plural = _("عينات المياه")

class WaterSampleMaterial(models.Model):
    watersample = models.ForeignKey(WaterSample, verbose_name=_("عينة المياة"), on_delete=models.CASCADE)
    WATERSAMPLEMATERIAL_TYPES = [
        ("آبار","آبار"),
        ("شبكات المياه","شبكات المياه"),
        ("المدارس","المدارس"),
        ("مساجد","مساجد"),
        ("المطاعم والمقاهي","المطاعم والمقاهي"),
        ("المياه المعدنية","المياه المعدنية"),
        ("سيارات نقل المياه","سيارات نقل المياه"),
        ("أخرى","أخرى"),
    ]
    watersamplematerial_type = models.CharField(_("نوع عينة المياه"), max_length=50)
    watersample_number = models.PositiveSmallIntegerField(_("رقم العينة"))
    brand_name = models.CharField(_("إسم العلامة التجارية"), max_length=50)
    capacity = models.PositiveSmallIntegerField(_("سعة العينة"))
    number_units = models.PositiveSmallIntegerField(_("عدد الوحدات"))
    date_withdrawal = models.DateField(_("تاريخ سحب العينة"), auto_now=False, auto_now_add=False)
    date_submit = models.DateField(_("تاريخ إرسال العينة"), auto_now=False, auto_now_add=False)
    material_because = models.CharField(_("نوع/سبب سحب العينة"), max_length=50)
    result = models.CharField(_("نتيجة العينة"), max_length=500)
    

    class Meta:
        verbose_name = _("بيانات عينة مياه")
        verbose_name_plural = _("بيانات عينات المياه")

    def __str__(self):
        return f"{self.watersamplematerial_type} | {self.result}"

class Initiative(models.Model):
    date = models.DateField(_("التاريخ"), auto_now=False, auto_now_add=False)
    day_name = models.CharField(_("اليوم"), max_length=50,null=True,blank=True)
    address = models.CharField(_("عنوان المبادرة"), max_length=500)
    initiative_type = models.CharField(_("نوع المبادرة"), max_length=50)
    detail = models.TextField(_("وصف المبادرة"))
    initiative_side = models.CharField(_("جهة تنفيذ المبادرة"), max_length=50)
    initiative_side_phone = models.PositiveBigIntegerField(_("رقم هاتف جهة التنفيذ"))
    qaim_name = models.CharField(_("إسم القائم على تنفيذ المبادرة"), max_length=50)
    file = models.FileField(_("مستند"), upload_to="rustaq_municipality/Initiative/file", max_length=100,null=True,blank=True)
    ORDERSTATUS = [
        ("مكتمل","مكتمل"),
        ("غير مكتمل","غير مكتمل"),
    ]
    orderstatu = models.CharField(_("حالة الطلب"), max_length=50,choices=ORDERSTATUS)
    
    notice = models.TextField(_("الملاحظات"))

    class Meta:
        verbose_name = _("توعية ومبادة")
        verbose_name_plural = _("التوعية والمبادرات")



class ButcheryOpera(models.Model):
    date = models.DateField(_("التاريخ"), auto_now=False, auto_now_add=False)
    beneficial = models.CharField(_("المستفيد"), max_length=50)
    inspector = models.ForeignKey(Inspector, verbose_name=_("المفتش"), on_delete=models.CASCADE,null=True,blank=True,editable=False)


    class Meta:
        verbose_name = _("قيد")
        verbose_name_plural = _("مسلخ دائرة البلدية بالرستاق")

    def __str__(self):
        return f"{self.date}|{self.beneficial}"
    
    def save(self,*args, **kwargs):
       
        if not getattr(self,"inspector_id"):
            inspector = Inspector.objects.filter(username=get_current_user().username)
            if inspector.exists():
                self.inspector = Inspector.objects.get(username=get_current_user().username)
        super().save(*args, **kwargs)
    
    @property
    def ButcheryOperaSalughter(self):
        return ButcheryOperaSalughter.objects.get(butcheryopera=self.id)
    
    @property
    @admin.display(description="جمال")
    def ButcheryOperaSalughter_beautys(self):
        return self.ButcheryOperaSalughter.beautys
    @property
    @admin.display(description="أبقار")
    def ButcheryOperaSalughter_cows(self):
        return self.ButcheryOperaSalughter.cows
    @property
    @admin.display(description="خراف")
    def ButcheryOperaSalughter_sheeps(self):
        return self.ButcheryOperaSalughter.sheeps
    @property
    @admin.display(description="أغنام")
    def ButcheryOperaSalughter_livestocks(self):
        return self.ButcheryOperaSalughter.livestocks
    @property
    @admin.display(description="إجمالي المذبوحات")
    def ButcheryOperaSalughter_total(self):
        return self.ButcheryOperaSalughter.total
    
    
    @property
    def ButcheryOperaTotalDamage(self):
        return ButcheryOperaTotalDamage.objects.get(butcheryopera=self.id)
    @property
    @admin.display(description="جمال")
    def ButcheryOperaTotalDamage_beautys(self):
        return self.ButcheryOperaTotalDamage.beautys
    @property
    @admin.display(description="أبقار")
    def ButcheryOperaTotalDamage_cows(self):
        return self.ButcheryOperaTotalDamage.cows
    @property
    @admin.display(description="خراف")
    def ButcheryOperaTotalDamage_sheeps(self):
        return self.ButcheryOperaTotalDamage.sheeps
    @property
    @admin.display(description="أغنام")
    def ButcheryOperaTotalDamage_livestocks(self):
        return self.ButcheryOperaTotalDamage.livestocks
    @property
    @admin.display(description="إجمالي الإتلاف الكلي")
    def ButcheryOperaTotalDamage_total(self):
        return self.ButcheryOperaTotalDamage.total
    
    @property
    def ButcheryOperaPartialDamage(self):
        return ButcheryOperaPartialDamage.objects.get(butcheryopera=self.id)
    @property
    @admin.display(description="جمال")
    def ButcheryOperaPartialDamage_beautys(self):
        return self.ButcheryOperaPartialDamage.beautys
    @property
    @admin.display(description="أبقار")
    def ButcheryOperaPartialDamage_cows(self):
        return self.ButcheryOperaPartialDamage.cows
    @property
    @admin.display(description="خراف")
    def ButcheryOperaPartialDamage_sheeps(self):
        return self.ButcheryOperaPartialDamage.sheeps
    @property
    @admin.display(description="أغنام")
    def ButcheryOperaPartialDamage_livestocks(self):
        return self.ButcheryOperaPartialDamage.livestocks
    @property
    @admin.display(description="إجمالي الإتلاف الجزئي")
    def ButcheryOperaPartialDamage_total(self):
        return self.ButcheryOperaPartialDamage.total
    
    @property
    @admin.display(description="إجمالي الإتلاف")
    def damage_total(self):
        return self.ButcheryOperaPartialDamage_total + self.ButcheryOperaTotalDamage_total



class ButcheryOperaSalughter(models.Model):
    butcheryopera = models.OneToOneField(ButcheryOpera, verbose_name=_("القيد"), on_delete=models.CASCADE)
    beautys = models.PositiveSmallIntegerField(_("جمال"))
    cows = models.PositiveSmallIntegerField(_("أبقار"))
    sheeps = models.PositiveSmallIntegerField(_("خراف"))
    livestocks = models.PositiveSmallIntegerField(_("أغنام"))
    total = models.PositiveIntegerField(_("العدد الإجمالي"),editable=False)
  

    class Meta:
        verbose_name = _("مذبوحة")
        verbose_name_plural = _("المذبوحات")

    def __str__(self):
        return f"{self.butcheryopera.date}|{self.total}"
    
    def save(self,*args, **kwargs):
        self.total = self.beautys + self.cows + self.sheeps + self.livestocks
        super().save(*args, **kwargs)

class ButcheryOperaTotalDamage(models.Model):
    butcheryopera = models.OneToOneField(ButcheryOpera, verbose_name=_("القيد"), on_delete=models.CASCADE)
    beautys = models.PositiveSmallIntegerField(_("جمال"))
    cows = models.PositiveSmallIntegerField(_("أبقار"))
    sheeps = models.PositiveSmallIntegerField(_("خراف"))
    livestocks = models.PositiveSmallIntegerField(_("أغنام"))
    total = models.PositiveIntegerField(_("العدد الإجمالي"),editable=False)
  

    class Meta:
        verbose_name = _("إتلاف كلي")
        verbose_name_plural = _("الإتلاف الكلي")

    def __str__(self):
        return f"{self.butcheryopera.date}|{self.total}"
    
    def save(self,*args, **kwargs):
        self.total = self.beautys + self.cows + self.sheeps + self.livestocks
        super().save(*args, **kwargs)

class ButcheryOperaPartialDamage(models.Model):
    butcheryopera = models.OneToOneField(ButcheryOpera, verbose_name=_("القيد"), on_delete=models.CASCADE)
    beautys = models.PositiveSmallIntegerField(_("جمال"))
    cows = models.PositiveSmallIntegerField(_("أبقار"))
    sheeps = models.PositiveSmallIntegerField(_("خراف"))
    livestocks = models.PositiveSmallIntegerField(_("أغنام"))
    total = models.PositiveIntegerField(_("العدد الإجمالي"),editable=False)
  

    class Meta:
        verbose_name = _("إتلاف جزئي")
        verbose_name_plural = _("الإتلاف الجزئي")

    def __str__(self):
        return f"{self.butcheryopera.date}|{self.total}"
    
    def save(self,*args, **kwargs):
        self.total = self.beautys + self.cows + self.sheeps + self.livestocks
        super().save(*args, **kwargs)





class DayR(models.Model):
    date_gte = models.DateField(_("من تاريخ"), auto_now=False, auto_now_add=False)
    date_lte = models.DateField(_("حتى تاريخ"), auto_now=False, auto_now_add=False)

    class Meta:
        verbose_name = _("تقرير يومي")
        verbose_name_plural = _("التقرير اليومي")

class MonthR(models.Model):
    date_gte = models.DateField(_("من تاريخ"), auto_now=False, auto_now_add=False)
    date_lte = models.DateField(_("حتى تاريخ"), auto_now=False, auto_now_add=False)

    class Meta:
        verbose_name = _("تقرير شهري")
        verbose_name_plural = _("التقرير الشهري")

class YearR(models.Model):
    date_gte = models.DateField(_("من تاريخ"), auto_now=False, auto_now_add=False)
    date_lte = models.DateField(_("حتى تاريخ"), auto_now=False, auto_now_add=False)

    class Meta:
        verbose_name = _("تقرير سنوي")
        verbose_name_plural = _("التقرير السنوي")








