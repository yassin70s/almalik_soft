from jazzmin.admin import *
from . import models

class ModelAdmin(ModelAdmin):
    report_address_list = [
        "محافظة جنوب الباطنة",
        "بلدية جنوب الباطنة",
        "دائرة البلدية بالرستاق",
        "قسم الرقابة والتراخيص الصحية"
    ]
    report_logo = "/static/logo_rustaq2.jpg"

class ModelReport(ModelReport,ModelAdmin):
    pass
class ViewSite(ViewSite):
    def index(self, request, extra_context=None):
        extra_context = extra_context or {}
        extra_context.update(
            licensing = {
                "count":models.Licensing.objects.count(),
                "url":reverse(f"{self.name}:rustaq_municipality_licensing_changelist"),
            },
            initiative = {
                "count":models.Initiative.objects.count(),
                "url":reverse(f"{self.name}:rustaq_municipality_initiative_changelist"),
            },
            activity = {
                "count":models.Activity.objects.count(),
                "url":reverse(f"{self.name}:rustaq_municipality_activity_changelist"),
            },
            inspector = {
                "count":models.Inspector.objects.count(),
                "url":reverse(f"{self.name}:rustaq_municipality_inspector_changelist"),
            },

            title = "بلدية الرستاق" + " - قسم التراخيص"
        )
        return super().index(request, extra_context)
view_site = ViewSite(name="view_site")
admin_site.register(
    model_or_iterable=[
        models.ActivityType,
        models.Village,
    ],
)

view_site.register(
    model_or_iterable=[
        models.ActivityType,
        models.Village,
    ],
)

class InspectorAdmin(ModelAdmin):
    fields = ["first_name","last_name","email","groups"]
    list_display = ["name","username","_groups","is_active","is_staff"]
    list_editable = ["is_active","is_staff"]
    filter_vertical = []
    filter_horizontal = []
admin_site.register(models.Inspector,InspectorAdmin)
view_site.register(models.Inspector,InspectorAdmin)

class UserAdmin(auth_admin.UserAdmin):
    fieldsets = (
        (None, {
            "fields": (
                "username","password",
            ),
        }),
        (None, {
            "fields": (
                "first_name","last_name","email",
            ),
        }),
        (None, {
            "fields": (
                "is_active","is_staff","groups","user_permissions",
            ),
        }),
    )
    filter_horizontal = []
    filter_vertical = []

    list_display = ["username","_groups","last_login","is_staff","date_joined",]
    list_editable = ["is_staff"]
    
    @display(description="المجموعات")
    def _groups(self,obj):
        content = ""
        for group in obj.groups.all():
            content += row(f"{group.name}")
        return format_html(content)
    
admin_site.register(auth_models.User,UserAdmin)
view_site.register(auth_models.User,UserAdmin)

class GroupAdmin(auth_admin.GroupAdmin):
    def has_delete_permission(self, request, obj = None):
        if not request.user.is_superuser:
            return False
        return super().has_delete_permission(request, obj)
    def has_change_permission(self, request, obj = None):
        if not request.user.is_superuser:
            return False
        return super().has_change_permission(request, obj)
    def has_add_permission(self, request):
        if not request.user.is_superuser:
            return False
        return super().has_add_permission(request)
    
    list_display = ["name","_permissions"]

    def _permissions(self,obj):
        content = ""
        for per in obj.permissions.all():
            content += row(per.name)
        return format_html(content)
    filter_horizontal = []
    filter_vertical =[]

    
admin_site.register(auth_models.Group,GroupAdmin)
view_site.register(auth_models.Group,GroupAdmin)

class ActivityAdmin(ModelAdmin):

    list_display = ["name","number_register","_activitytypes","activitycategore","village","address","notice","date_last_visit"]
    search_fields = ["name"]
    report_fieldsets = [
        fieldset(fieldset_rows=[
            fieldset_row(fields=[
                fieldset_field("activitys_count")
            ])
        ])
    ]
    @display(description="إجمالي: ")
    def activitys_count(self,request):
        return self.get_queryset(request).count()
#view_site.register(models.Activity,ActivityAdmin)
view_site.register(models.Activity,ActivityAdmin)

class LicensingAdmin(ModelAdmin):
    actions_on_bottom = True
    actions_on_top = False
    is_viewer = True

    list_display = [
        "date","orderstatu","_limitation_type","inspector","_activity_name",
        "_activity_number_register","_activity_activitytype","procedure",
    ]
    list_filter = ["activity__name","orderstatu"]
    def has_add_permission(self, request):
        return False
    def has_change_permission(self, request, obj = None):
        return False
    
    #search_fields = ["activity__name",]
    def changeform_view(self, request, object_id=None, form_url="", extra_context=None):
        obj = models.Licensing.objects.get(id=object_id)
        return HttpResponseRedirect(reverse(f"{self.admin_site.name}:{self.opts.app_label}_{obj.limitation_type.lower()}_change",kwargs={"object_id":obj.id}))
    def viewerform_view(self, request, object_id=None, form_url="", extra_context=None):
        obj = models.Licensing.objects.get(id=object_id)
        return HttpResponseRedirect(reverse(f"{self.admin_site.name}:{self.opts.app_label}_{obj.limitation_type.lower()}_viewer",kwargs={"object_id":obj.id}))


    report_fieldsets = [
        fieldset(fieldset_rows=[
            fieldset_row(fields=[
                fieldset_field("total")
            ])
        ])
    ]
    @display(description="إجمالي: ")
    def total(self,request):
        return self.get_queryset(request).count()
    report_is_horizontal = False
    

view_site.register(models.Licensing,LicensingAdmin)

class LicensingParts(ModelAdmin):
    is_api_change_form = True
    def response_post_save_add(self, request, obj):
        return HttpResponseRedirect(reverse(f"{self.admin_site.name}:{self.opts.app_label}_licensing_changelist"))
    def response_post_save_change(self, request, obj):
        return HttpResponseRedirect(reverse(f"{self.admin_site.name}:{self.opts.app_label}_licensing_changelist"))
    def has_module_permission(self, request):
        return False
    def api_data_form(self, request, data):
        print(data)
        data["day_name"]["disabled"] = True
        data["activity_type"]["disabled"] = True
        data["activity_categore"]["disabled"] = True
        data["activity_address"]["disabled"] = True

        if data["date"]["value"]:
            date = parse_date(str(data["date"]["value"]))
            data["day_name"]["value"] = day_name(date)
        if data["activity"]["value"]:
            activity = models.Activity.objects.get(id=int(data["activity"]["value"]))
            data["activity_type"]["value"] = activity.activitytype.name
            data["activity_categore"]["value"] = activity.activitycategore
            data["activity_address"]["value"] = activity.address
        
        return super().api_data_form(request, data)
   
class VisitView(LicensingParts,ModelActionReport):
    
    fieldsets = (
        ("تفاصيل الزيارة", {
            "fields": (
                ("date","day_name",),("activity",),
                ("activity_type","activity_categore",),
                ("activity_address",),
                ("procedure","orderstatu",),("detail","notice",),
                ("file",),
            ),
        }),
    )
    

    report_fieldsets = [
        (None,[
            fieldset_row(fields=[
                fieldset_field("date",width="40%",width_label="10%"),
                fieldset_field("_id",width="40%",width_label="10%")
            ]),
            fieldset_row(fields=[
                fieldset_field("inspector"),
                fieldset_field(),

            ])
        ]),
        (None,[
            fieldset_row(fields=[
                fieldset_field("_activity_name",width="20%",width_label="13%"),
                fieldset_field("_activity_number_register",width="20%",width_label="13%"),
                fieldset_field("_activity_activitytype",width="20%",width_label="14%")
            ]),
            fieldset_row(fields=[
                fieldset_field("_activity_activitycategore"),
                fieldset_field(),
                fieldset_field(),
            ]),
            fieldset_row(fields=[
                fieldset_field("procedure"),
                fieldset_field("orderstatu"),
                fieldset_field()
            ]),
          
        ]),
        (None,[
            fieldset_row(fields=[
                fieldset_field("detail",width="90%",width_label="10%"),
  
            ]),
            fieldset_row(fields=[
                fieldset_field("notice"),
                
            ]),
            
          
        ])

    ]
    
    report_title = "الزيارات اليومية - تفاصيل الزيارة"
    
    def report_get_context(self, request, object_id=None, extra_context=None):
        context = {}
        report_get_context = super().report_get_context(request, object_id, extra_context)
        content = ""

        
        
      
        context.update(
            content = format_html(content),

            **report_get_context
        )
        return context
    
view_site.register(models.Visit,VisitView)


class ViolationView(LicensingParts,ModelActionReport):

    fieldsets = (
        (None, {
            "fields": (
                "date","day_name","activity",
                "activity_name","activity_type","activity_number_register","activity_address",
                "procedure",
                "item","number","amount_fine",
                "detail","notice","orderstatu","file",
            ),
        }),
    )

    

    report_fieldsets = [
        (None,[
            fieldset_row(fields=[
                fieldset_field("date",width="40%",width_label="10%"),
                fieldset_field("_id",width="40%",width_label="10%")
            ]),
            fieldset_row(fields=[
                fieldset_field("inspector"),
                fieldset_field("number"),

            ])
        ]),
        (None,[
            fieldset_row(fields=[
                fieldset_field("_activity_name",width="20%",width_label="13%"),
                fieldset_field("_activity_number_register",width="20%",width_label="13%"),
                fieldset_field("_activity_activitytype",width="20%",width_label="14%")
            ]),
            fieldset_row(fields=[
                fieldset_field(),
                fieldset_field(),
                fieldset_field()
            ]),
            fieldset_row(fields=[
                fieldset_field("orderstatu"),
                fieldset_field("amount_fine"),
                fieldset_field()
            ]),
          
        ]),
        (None,[
            fieldset_row(fields=[
                fieldset_field("detail",width="90%",width_label="10%"),
  
            ]),
            fieldset_row(fields=[
                fieldset_field("notice"),
                
            ]),
        ])
    ]
    report_title = "المخالفات الصية - تفاصيل المخالفة"
    
view_site.register(models.Violation,ViolationView)

class ComplaintView(LicensingParts,ModelActionReport):

    fieldsets = (
        ("تسجيل الشكاو ...", {
            "fields": (
                "date","day_name",
                "complaint_type","complaint_side","phone","detail",
                "activity",
                "activity_type","activity_categore","activity_address",
            ),
        }),
        ("تسجيل الشكاو ...", {
            "fields": (
                "procedure","detail_procedure","notice","date_end","orderstatu","file",
                
            ),
        }),
    )
    


    report_fieldsets = [
        (None,[
            fieldset_row(fields=[
                fieldset_field("date",width="40%",width_label="10%"),
                fieldset_field("_id",width="40%",width_label="10%")
            ]),
            fieldset_row(fields=[
                fieldset_field("inspector"),
                fieldset_field(""),

            ])
        ]),
        (None,[
            fieldset_row(fields=[
                fieldset_field("_activity_name",width="20%",width_label="13%"),
                fieldset_field("_activity_number_register",width="20%",width_label="13%"),
                fieldset_field("_activity_activitytype",width="20%",width_label="14%")
            ]),
            fieldset_row(fields=[
                fieldset_field("_activity_village"),
                fieldset_field(),
                fieldset_field("complaint_type")
            ]),
            fieldset_row(fields=[
                fieldset_field("orderstatu"),
                fieldset_field("date_end"),
                fieldset_field()
            ]),
            fieldset_row(fields=[
                fieldset_field("complaint_side"),
                fieldset_field("phone"),
                fieldset_field()
            ]),
          
        ]),
        (None,[
            fieldset_row(fields=[
                fieldset_field("detail",width="90%",width_label="10%"),
  
            ]),
            fieldset_row(fields=[
                fieldset_field("notice"),
                
            ]),
        ])
    ]
    report_title = ""
    
view_site.register(models.Complaint,ComplaintView)


class DamageMaterialInline(TabularInline):
    model = models.DamageMaterial
    extra = 0
    min_num = 1
    fields = ["material_type","because","total","setting_number","release_number","damage_number"]
class DamageView(LicensingParts,ModelActionReport):

    fieldsets = (
        ("بيانات المنشة", {
            "fields": (
                "date","day_name","activity",
                "activity_name","activity_number_register","activity_type","activity_categore","activity_address",
            ),
        }),
        ("الجرا", {
            "fields": (
                "procedure","orderstatu","notice","file",

            ),
        }),
    )
    


    report_fieldsets = [
        (None,[
            fieldset_row(fields=[
                fieldset_field("date",width="40%",width_label="10%"),
                fieldset_field("_id",width="40%",width_label="10%")
            ]),
            fieldset_row(fields=[
                fieldset_field("inspector"),
                fieldset_field(),

            ])
        ]),
        (None,[
            fieldset_row(fields=[
                fieldset_field("_activity_name",width="20%",width_label="13%"),
                fieldset_field("_activity_number_register",width="20%",width_label="13%"),
                fieldset_field("_activity_activitytype",width="20%",width_label="14%")
            ]),
            fieldset_row(fields=[
                fieldset_field("_activity_address"),
                fieldset_field(),
                fieldset_field()
            ]),
            fieldset_row(fields=[
                fieldset_field("damage_because"),
                fieldset_field(),
                fieldset_field()
            ]),
          
        ]),

    ]
    
    #report_title = "محر اتلاف"
    
    inlines = [DamageMaterialInline]
    report_inline_fieldsets = (
        (None, {
            "fields": (
                "_id","material_type","because","total","setting_number","release_number","damage_number",
            ),
        }),
    )
view_site.register(models.Damage,DamageView)


class FoodSampleMaterialInline(TabularInline):
    model = models.FoodSampleMaterial
    extra = 0
    min_num = 1
    fields = ["foodsamplematerial_type","foodsample_number","product_name","number_units","date_withdrawal","date_submit","material_because","result"]
class FoodSampleView(LicensingParts,ModelActionReport):

    fieldsets = (
        (None, {
            "fields": (
                "date","day_name","activity",
                "activity_name","activity_number_register","activity_type","activity_categore","activity_address",
            ),
        }),
        ("الجرا", {
            "fields": (
                "procedure","orderstatu","notice",

            ),
        }),
    )
    


    report_fieldsets = [
        (None,[
            fieldset_row(fields=[
                fieldset_field("date",width="40%",width_label="10%"),
                fieldset_field("_id",width="40%",width_label="10%")
            ]),
            fieldset_row(fields=[
                fieldset_field("inspector"),
                fieldset_field(),

            ])
        ]),
        (None,[
            fieldset_row(fields=[
                fieldset_field("_activity_name",width="20%",width_label="13%"),
                fieldset_field("_activity_number_register",width="20%",width_label="13%"),
                fieldset_field("_activity_activitytype",width="20%",width_label="14%")
            ]),
            fieldset_row(fields=[
                fieldset_field("_activity_village"),
                fieldset_field(),
                fieldset_field()
            ]),
            fieldset_row(fields=[
                fieldset_field(),
                fieldset_field("orderstatu"),
                fieldset_field()
            ]),
          
        ]),

    ]
    
    #report_title = "عينات الأغذية"
    inlines = [FoodSampleMaterialInline]
    report_inline_fieldsets = (
        (None, {
            "fields": (
                "foodsamplematerial_type","foodsample_number","product_name","number_units",
                "date_withdrawal","date_submit","material_because","result",
            ),
        }),
    )
view_site.register(models.FoodSample,FoodSampleView)


class WaterSampleMaterialInline(TabularInline):
    model = models.WaterSampleMaterial
    extra = 0
    min_num = 1
    fields = ["watersamplematerial_type","watersample_number","brand_name",
              "capacity","number_units","date_withdrawal","date_submit","material_because","result"]

class WaterSampleView(LicensingParts,ModelActionReport):
    fieldsets = (
        (None, {
            "fields": (
                "date","day_name","activity",
                "activity_name","activity_number_register","activity_type","activity_categore","activity_address",
            ),
        }),
        ("الجرا", {
            "fields": (
                "procedure","orderstatu","notice",

            ),
        }),
    )
    report_fieldsets = [
        (None,[
            fieldset_row(fields=[
                fieldset_field("date",width="40%",width_label="10%"),
                fieldset_field("_id",width="40%",width_label="10%")
            ]),
            fieldset_row(fields=[
                fieldset_field("inspector"),
                fieldset_field(),

            ])
        ]),
        (None,[
            fieldset_row(fields=[
                fieldset_field("_activity_name",width="20%",width_label="13%"),
                fieldset_field("_activity_number_register",width="20%",width_label="13%"),
                fieldset_field("_activity_activitytype",width="20%",width_label="14%")
            ]),
            fieldset_row(fields=[
                fieldset_field("_activity_village"),
                fieldset_field(),
                fieldset_field()
            ]),
            fieldset_row(fields=[
                fieldset_field(),
                fieldset_field("orderstatu"),
                fieldset_field()
            ]),
          
        ]),

    ]
    
    #report_title = "عينات المياه"

    report_inline_fieldsets = (
        (None, {
            "fields": (
                "watersamplematerial_type","foodsample_number","brand_name","capacity","number_units",
                "date_withdrawal","date_submit","material_because","result",
            ),
        }),
    )
    
    inlines = [WaterSampleMaterialInline]
view_site.register(models.WaterSample,WaterSampleView)


class InitiativeAdmin(ModelAdmin):
    fieldsets = (
        (None, {
            "fields": (
                "date","day_name","address","initiative_type","detail","initiative_side",
                "initiative_side_phone","qaim_name","orderstatu","notice","file"
            ),
        }),
    )
    
    is_viewer = True
    list_display = [
        "date","address","initiative_type","detail","initiative_side","initiative_side_phone","qaim_name","orderstatu","notice"
    ]
    is_api_change_form = True
    def api_data_form(self, request, data):
        data["day_name"]["disabled"] = True
        if data["date"]["value"]:
            date = parse_date(str(data["date"]["value"]))
            data["day_name"]["value"] = day_name(date)
        return super().api_data_form(request, data)
    report_fieldsets = [
        (None,[
            fieldset_row(fields=[
                fieldset_field("date",width="40%",width_label="10%"),
                fieldset_field("day_name",width="40%",width_label="10%")
            ]),
            
        ]),
        (None,[
            fieldset_row(fields=[
                fieldset_field("address",width="20%",width_label="13%"),
                fieldset_field("initiative_type",width="20%",width_label="13%"),
                fieldset_field("detail",width="20%",width_label="14%")
            ]),
            fieldset_row(fields=[
                fieldset_field("initiative_side",width="20%",width_label="13%"),
                fieldset_field("qaim_name",width="20%",width_label="13%"),
                fieldset_field("orderstatu",width="20%",width_label="14%")
            ]),

          
        ]),
        (None,[
            fieldset_row(fields=[
                fieldset_field("notice",width="20%",width_label="13%"),
            ]),
        ])
    ]
    #report_title = "التوعية والمادرات - تفاصيل المادرة"
    
view_site.register(models.Initiative,InitiativeAdmin)



class ButcheryOperaSalughterInline(TabularInline):
    model = models.ButcheryOperaSalughter
    min_num = 1
class ButcheryOperaTotalDamageInline(TabularInline):
    model = models.ButcheryOperaTotalDamage
    min_num = 1
class ButcheryOperaPartialDamageInline(TabularInline):
    model = models.ButcheryOperaPartialDamage
    min_num = 1

class ButcheryOperaAdmin(ModelAdmin):
    list_display = [
        "inspector","beneficial","date",
        "ButcheryOperaSalughter_beautys","ButcheryOperaSalughter_cows","ButcheryOperaSalughter_sheeps","ButcheryOperaSalughter_livestocks","ButcheryOperaSalughter_total",
        "ButcheryOperaTotalDamage_beautys","ButcheryOperaTotalDamage_cows","ButcheryOperaTotalDamage_sheeps","ButcheryOperaTotalDamage_livestocks","ButcheryOperaTotalDamage_total",
        "ButcheryOperaPartialDamage_beautys","ButcheryOperaPartialDamage_cows","ButcheryOperaPartialDamage_sheeps","ButcheryOperaPartialDamage_livestocks","ButcheryOperaPartialDamage_total",
        "damage_total",
    ]
    inlines = [
        ButcheryOperaSalughterInline,
        ButcheryOperaTotalDamageInline,
        ButcheryOperaPartialDamageInline,
    ]
    
    @display(description="date")
    def date_gte(self,request):
        return ""
    def report_result_list_html(self,request):
        cl = self.get_changelist_instance(request)
        cl.formset = None
        cl.list_display = self.report_get_list_display(request)
        cl.show_admin_actions = False
        
        _result_list = result_list(cl)

        _ths = [
            
            [
                th(content="المفتش",rowspan=3),
                th(content="المستفيد",rowspan=3),
                th(content="التاريخ",rowspan=3),
                th(content="قسم المذبوحات",colspan=5),
                th(content="قسم الإتلافات",colspan=10),
                th(content="إجمالي الإتلافات" + " (كجم)",rowspan=3),

            ],
            [
                th(content="جمال",rowspan=2),
                th(content="أبقار",rowspan=2),
                th(content="خراف",rowspan=2),
                th(content="أغنام",rowspan=2),
                th(content="إجمالي المذبوحات",rowspan=2),
                th(content="الإتلاف الكلي",colspan=5),
                th(content="الإتلاف الجزئي",colspan=5),
                

            ],
            [
                
                th(content="جمال"),
                th(content="أبقار"),
                th(content="خراف"),
                th(content="أغنام"),
                th(content="إجمالي الإتلافات الكلي"),
                th(content="جمال"),
                th(content="أبقار"),
                th(content="خراف"),
                th(content="أغنام"),
                th(content="إجمالي الإتلافات الجزئي"),

            ],
        ]
        content = row(table(th_lists=_ths,td_lists=_result_list["results"]),classes=" mt-2")
        return format_html(content)
    report_title = "إحائيات بدد المذبوحات في مسلخ دائر البلدي بالرستاق خلال سن 2024م"
    report_is_horizontal = False
    
view_site.register(models.ButcheryOpera,ButcheryOperaAdmin)








################# reports ###############################################


class DayReport(ModelReport):
    report_fieldsets = [
        fieldset(fieldset_rows=[
            fieldset_row(fields=[
                fieldset_field("date_gte",width="35%",width_label="15%"),
                fieldset_field("date_lte",width="35%",width_label="15%"),
            ]),
        ]),
    ]
    def report_get_context(self, request, object_id=None, extra_context=None):
        date_gte = parse_date(str(self.data["date_gte"][0]))
        date_lte = parse_date(str(self.data["date_lte"][0]))

        results = []
        total = [
            "",
            "",
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,            
        ]
        week_style_1="background-color: rgb(160, 235, 235);"
        week_style_2="background-color: rgb(226, 203, 140);"
        week_style = week_style_2
        for day in range(date_gte.toordinal(),date_lte.toordinal()+1):
            date = datetime.fromordinal(day).date()
            

            Visit = models.Visit.objects.filter(date=date)
            DamageMaterial = models.DamageMaterial.objects.filter(damage__date=date)
            Licensing = models.Licensing.objects.filter(date=date)
        
            result = [
                day_name(date),
                date_format(date),
                Visit.count(),
                models.Violation.objects.filter(date=date).count(),
                Licensing.filter(procedure="توجيه").count(),
                DamageMaterial.aggregate(total_total=Sum("total",default=0))["total_total"],
                DamageMaterial.aggregate(damage_number_total=Sum("damage_number",default=0))["damage_number_total"],
                Licensing.filter(procedure="مغلق أثناء الزيارة").count(),
                Licensing.filter(activity__activitycategore="عالي الخطورة").count(),
                Licensing.filter(activity__activitycategore="متوسط الخطورة").count(),
                Licensing.filter(procedure="غلق المنشأة").count(),
            ]

            results += [
                [td(i,style=week_style) for i in result]
            ]
            if date.weekday() == 5:
                results += [
                    [td("المجموع",colspan="2",style="background-color: rgb(235, 91, 91);border: 2px solid black;")]+[
                        td(i,style="background-color: rgb(235, 91, 91);border: 2px solid black;") for i in total[2:]
                    ]
                ]
                for res in range(len(result)):
                    if res >= 2:
                        total[res] = 0
                if week_style == week_style_1:
                    week_style = week_style_2
                elif week_style == week_style_2:
                    week_style = week_style_1
            else:
                for res in range(len(result)):
                    if res >= 2:
                        total[res] += result[res]
        
        result_headers = [
            th("اليوم"),
            th("التاريخ"),
            th("عدد الزيارات"),
            th("عدد المخالفات"),
            th("عدد التوجيهات"),
            th("كمية المادة المتلفة (كجم)"),
            th("عدد المادة المتلفة"),
            th("عدد المنشآت المغلقة أثناء الزيارة"),
            th("عدد المنشآت عالية الخطورة"),
            th("عدد المنشآت متوسطة الخطورة"),
            th("عدد الغلق"),
        ]
        extra_context = extra_context or {}
        extra_context.update(
            
            report_result_list_html = row(table(th_lists=[result_headers],td_lists=results))
        )
        return super().report_get_context(request, object_id, extra_context)
view_site.register(models.DayR,DayReport)

class MonthReport(ModelReport):
    report_fieldsets = [
        fieldset(fieldset_rows=[
            fieldset_row(fields=[
                fieldset_field("date_gte",width="35%",width_label="15%"),
                fieldset_field("date_lte",width="35%",width_label="15%"),
            ]),
        ]),

    ]
    def report_get_context(self, request, object_id=None, extra_context=None):
        date_gte = parse_date(str(self.data["date_gte"][0]))
        date_lte = parse_date(str(self.data["date_lte"][0]))

        results = []
        total = [
            "",
            "",
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,            
        ]
        month_style_1="background-color: rgb(160, 235, 235);"
        month_style_2="background-color: rgb(226, 203, 140);"
        month_style = month_style_2

        months = {
            "name":0,
            "weeks":[
                {
                    "date_gte":0,
                    "date_lte":0,
                }
            ]
        }
        months_data ={}
        week_month_number = 0
        weeks_names = {
            1:"الأسبوع الأول",
            2:"الأسبوع الثاني",
            3:"الأسبوع الثالث",
            4:"الأسبوع الرابع",
            5:"الأسبوع الخامس",
            6:"الأسبوع 6",
        }
        for day in range(date_gte.toordinal(),date_lte.toordinal()+1):
            date = datetime.fromordinal(day).date()
            if not date.year in months_data:
                months_data[date.year] = {
                }
            
            if not date.month in months_data[date.year]:
                months_data[date.year][date.month]={
                    
                }
                week_month_number = 1
                
            if not week_month_number in months_data[date.year][date.month]:
                months_data[date.year][date.month][week_month_number] = {
                    "date_gte":None,
                    "date_lte":None,
                    "week_name":"",
                    "data":[
                        0,
                        0,
                        0, #التوجيهلت
                        0,
                        0,
                        0,
                        0,
                        0,
                        0, 
                    ]
                }
            
            
            Visit = models.Visit.objects.filter(date=date)
            DamageMaterial = models.DamageMaterial.objects.filter(damage__date=date)
            Licensing = models.Licensing.objects.filter(date=date)
            result = [
                Visit.count(),
                models.Violation.objects.filter(date=date).count(),
                Licensing.filter(procedure="توجيه").count(),
                DamageMaterial.aggregate(total_total=Sum("total",default=0))["total_total"],
                DamageMaterial.aggregate(damage_number_total=Sum("damage_number",default=0))["damage_number_total"],
                Licensing.filter(procedure="مغلق أثناء الزيارة").count(),
                Licensing.filter(activity__activitycategore="عالي الخطورة").count(),
                Licensing.filter(activity__activitycategore="متوسط الخطورة").count(),
                Licensing.filter(procedure="غلق المنشأة").count(),
            ]
            if not months_data[date.year][date.month][week_month_number]["date_gte"]:
                months_data[date.year][date.month][week_month_number]["date_gte"] = date_format(date)
            months_data[date.year][date.month][week_month_number]["date_lte"] = date_format(date)
            months_data[date.year][date.month][week_month_number]["week_name"] = weeks_names[week_month_number]

            for i_res in range(len(result)):
                months_data[date.year][date.month][week_month_number]["data"][i_res] += result[i_res]

            if date.weekday() == 5:
                week_month_number += 1
            
        
        
        result_headers = [
            th("الأسبوع"),
            th("الفترة الزمنية"),
            th("عدد الزيارات"),
            th("عدد المخالفات"),
            th("عدد التوجيهات"),
            th("كمية المادة المتلفة (كجم)"),
            th("عدد المادة المتلفة"),
            th("عدد المنشآت المغلقة أثناء الزيارة"),
            th("عدد المنشآت عالية الخطورة"),
            th("عدد المنشآت متوسطة الخطورة"),
            th("عدد الغلق"),
        ]
        content = ""
        for year, months in months_data.items():
            tds_month = ""
            for month, weeks in months.items():
                tds_weeks = []
                tds_total = [0,0,0,0,0,0,0,0,0]
                for week, week_content in weeks.items():
                    _tds_week = []
                    _tds_week += [
                        td(week_content["week_name"]),
                        td(f"{week_content['date_gte']} \n {week_content['date_lte']}"),
                    ]
                    for da in range(len(week_content["data"])):
                        _tds_week += [td(week_content["data"][da])]
                        tds_total[da] += week_content["data"][da]
                    tds_weeks += [_tds_week]
                tds_weeks += [[
                    td("المجموع",colspan=2)] + [td(to) for to in tds_total
                ]]
                _result_headers = [[
                    th(f"الشهر: {month}",colspan=11)
                ],
                result_headers
                ]
                tds_month += row(table(th_lists=_result_headers,td_lists=tds_weeks),classes="mb-2")
            content += tds_month
        
        
        extra_context = extra_context or {}
        extra_context.update(
            
            report_result_list_html = format_html(content)
        )
        return super().report_get_context(request, object_id, extra_context)

view_site.register(models.MonthR,MonthReport)

class YearReport(ModelReport):
    report_fieldsets = [
        fieldset(fieldset_rows=[
            fieldset_row(fields=[
                fieldset_field("date_gte",width="35%",width_label="15%"),
                fieldset_field("date_lte",width="35%",width_label="15%"),
            ]),
        ]),

    ]
    def report_get_context(self, request, object_id=None, extra_context=None):
        date_gte = parse_date(str(self.data["date_gte"][0]))
        date_lte = parse_date(str(self.data["date_lte"][0]))

        
      
        year_style_1="background-color: rgb(160, 235, 235);"
        year_style_2="background-color: rgb(226, 203, 140);"
        year_style = year_style_2
        years_data = {}
        for day in range(date_gte.toordinal(),date_lte.toordinal()+1):
            date = datetime.fromordinal(day).date()
            if not date.year in years_data:
                years_data[date.year] = {
                }
            if not date.month in years_data[date.year]:
                years_data[date.year][date.month]={
                    "month_name":month_name(date),
                    "data":[
                        0,
                        0,
                        0, #التوجيهلت
                        0,
                        0,
                        0,
                        0,
                        0,
                        0,
                    ]  
                }

            Visit = models.Visit.objects.filter(date=date)
            DamageMaterial = models.DamageMaterial.objects.filter(damage__date=date)
            Licensing = models.Licensing.objects.filter(date=date)
            result = [
                Visit.count(),
                models.Violation.objects.filter(date=date).count(),
                Licensing.filter(procedure="توجيه").count(),
                DamageMaterial.aggregate(total_total=Sum("total",default=0))["total_total"],
                DamageMaterial.aggregate(damage_number_total=Sum("damage_number",default=0))["damage_number_total"],
                Licensing.filter(procedure="مغلق أثناء الزيارة").count(),
                Licensing.filter(activity__activitycategore="عالي الخطورة").count(),
                Licensing.filter(activity__activitycategore="متوسط الخطورة").count(),
                Licensing.filter(procedure="غلق المنشأة").count(),
            ]

            for i_res in range(len(result)):
                years_data[date.year][date.month]["data"][i_res] += result[i_res]
        content = ""
        result_headers = [
            th("الشر"),
            th("عدد الزيارات"),
            th("عدد المخالفات"),
            th("عدد التوجيهات"),
            th("كمية المادة المتلفة (كجم)"),
            th("عدد المادة المتلفة"),
            th("عدد المنشآت المغلقة أثناء الزيارة"),
            th("عدد المنشآت عالية الخطورة"),
            th("عدد المنشآت متوسطة الخطورة"),
            th("عدد الغلق"),
        ]
        for year, months in years_data.items():
            _tds_months_year = []
            _total_months = [0,0,0,0,0,0,0,0,0]

            for month, month_values in months.items():
                _tds_month = [td(month_values["month_name"])]
                for i_td_month in range(len(month_values["data"])):
                    _tds_month += [
                        td(month_values["data"][i_td_month])
                    ]
                    _total_months[i_td_month] += month_values["data"][i_td_month]
                _tds_months_year += [_tds_month]
            _tds_months_year += [[td("المجمو: ")] + [td(to) for to in _total_months]]

            _result_headers = [
                [th(f"{year}",colspan=len(result_headers))],
                result_headers,
            ]
            content += row(table(th_lists=_result_headers,td_lists=_tds_months_year),classes=" mb-2 ")


        
        
        

        extra_context = extra_context or {}
        extra_context.update(
            
            report_result_list_html = format_html(content)
        )
        return super().report_get_context(request, object_id, extra_context)

view_site.register(models.YearR,YearReport)