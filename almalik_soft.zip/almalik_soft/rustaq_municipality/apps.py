from django.apps import AppConfig



class RustaqMunicipalityConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'rustaq_municipality'
    verbose_name = "بلدية الرستاق"

    