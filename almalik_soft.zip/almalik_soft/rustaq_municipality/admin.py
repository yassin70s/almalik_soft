from almalik_soft.admin import *
from . import models


view_site.register(
    model_or_iterable=[
        models.ActivityCategore,models.ActivityType,
        models.ComplaintSide,models.ComplaintType,
        models.DamageBecause,models.Material,
        models.OrderStatu,
        models.Product,
        models.Procedure,
        models.Village,
        models.Inspector,
        models.FoodSampleBecause, models.FoodSampleMaterialType,
        models.WaterSampleBecause, models.WaterSampleMaterialType,


    ],
)

class ActivityAdmin(ModelAdmin):
    search_fields = ["name"]
view_site.register(models.Activity,ActivityAdmin)

class LicensingAdmin(ModelAdmin):
    list_display = [
        "date","orderstatu","_id","_limitation_type","inspector","_activity_name",
        "_activity_number_register","_activity_activitytype","_activity_village","procedure",
    ]
    def has_add_permission(self, request):
        return False
    def has_change_permission(self, request, obj = None):
        return False
    list_filter = [
        "date","orderstatu","limitation_type","inspector",
        "activity__activitytype","activity__village","procedure",
    ]
    search_fields = ["activity__name",]
view_site.register(models.Licensing,LicensingAdmin)

class VisitAdmin(ModelAdmin):
    pass
view_site.register(models.Visit,VisitAdmin)

class InitiativeAdmin(ModelAdmin):
    pass
view_site.register(models.Initiative,InitiativeAdmin)

class ViolationAdmin(ModelAdmin):
    pass
view_site.register(models.Violation,ViolationAdmin)

class ComplaintAdmin(ModelAdmin):
    pass
view_site.register(models.Complaint,ComplaintAdmin)


class DamageMaterialInline(TabularInline):
    model = models.DamageMaterial
    extra = 0
    min_num = 1
class DamageAdmin(ModelAdmin):
    inlines = [DamageMaterialInline]
view_site.register(models.Damage,DamageAdmin)


class FoodSampleMaterialInline(TabularInline):
    model = models.FoodSampleMaterial
    extra = 0
    min_num = 1
class FoodSampleAdmin(ModelAdmin):
    inlines = [FoodSampleMaterialInline]
view_site.register(models.FoodSample,FoodSampleAdmin)


class WaterSampleMaterialInline(TabularInline):
    model = models.WaterSampleMaterial
    extra = 0
    min_num = 1
class WaterSampleAdmin(ModelAdmin):
    inlines = [WaterSampleMaterialInline]
view_site.register(models.WaterSample,WaterSampleAdmin)










################# reports ###############################################

