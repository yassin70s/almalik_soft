
from django.db import models
from django.urls import reverse
from django.contrib.contenttypes import models as contenttype_models
from django.utils.translation import gettext as _
from django.contrib.auth import models as auth_models
from django.contrib import admin


class Inspector(models.Model):
    name = models.CharField(_("اسم المفتش"), max_length=50)
    
    class Meta:
        verbose_name = _("مفتش")
        verbose_name_plural = _("المفتشين")

    def __str__(self):
        return self.name





class ActivityType(models.Model):
    name = models.CharField(_("نوع النشاط"), max_length=50)
    
    class Meta:
        verbose_name = _("نوع نشاط")
        verbose_name_plural = _("أنواع الأنشطة")

    def __str__(self):
        return self.name

class ActivityCategore(models.Model):
    name = models.CharField(_("تصنيف النشاط"), max_length=50)
    
    class Meta:
        verbose_name = _("تصنيف نشاط")
        verbose_name_plural = _("تصنيفات الأنشطة")

    def __str__(self):
        return self.name

class Village(models.Model):
    name = models.CharField(_("اسم القرية"), max_length=50)
    
    class Meta:
        verbose_name = _("قرية")
        verbose_name_plural = _("القرى")

    def __str__(self):
        return self.name


class Activity(models.Model):
    name = models.CharField(_("اسم النشاط"), max_length=50)
    number_register = models.PositiveBigIntegerField(_("رقم السجل التجاري"))
    activitytype = models.ForeignKey(ActivityType, verbose_name=_("نوع النشاط"), on_delete=models.CASCADE)
    activitycatrgore = models.ForeignKey(ActivityCategore, verbose_name=_("تصنيف النشاط"), on_delete=models.CASCADE)
    address = models.CharField(_("العنوان"), max_length=500)
    village = models.ForeignKey(Village, verbose_name=_("القرية"), on_delete=models.CASCADE)
    notice = models.TextField(_("ملاحظات"),null=True,blank=True)


    @property
    def date_last_visit(self):
        return self.visits.last()

    @property
    def visits(self):
        return Visit.objects.filter(activity=self)
    
    class Meta:
        verbose_name = _("نشاط")
        verbose_name_plural = _("الأنشطة")

    def __str__(self):
        return self.name

class Procedure(models.Model):
    name = models.CharField(_("اسم الإجراء"), max_length=50)
    

    class Meta:
        verbose_name = _("إجراء")
        verbose_name_plural = _("الإجراءات")

    def __str__(self):
        return self.name

class OrderStatu(models.Model):
    name = models.CharField(_("حالة الطلب"), max_length=50)
    

    class Meta:
        verbose_name = _("حالة طلب")
        verbose_name_plural = _("حالات الطلب")

    def __str__(self):
        return self.name

class Licensing(models.Model):
    activity = models.ForeignKey(Activity, verbose_name=_("النشاط"), on_delete=models.CASCADE)
    date = models.DateField(_("تاريخ الزيارة"), auto_now=False, auto_now_add=False)
    inspector = models.ForeignKey(Inspector, verbose_name=_("المفتش"), on_delete=models.CASCADE)
    procedure = models.ForeignKey(Procedure, verbose_name=_("الإجراء"), on_delete=models.CASCADE)
    orderstatu = models.ForeignKey(OrderStatu, verbose_name=_("حالة الطلب"), on_delete=models.CASCADE)
    limitation_type = models.CharField(_("نوع القيد"), max_length=50,choices=[
        ("Visit","Visit"),
        ("Initiative","Initiative"),
        ("Violation","Violation"),
        ("Complaint","Complaint"),
        ("Damage","Damage"),
    ],editable=False)
    @property
    @admin.display(description="رقم التقرير")
    def _id(self):
        return self.pk
    @property
    @admin.display(description="نوع القيد")
    def _limitation_type(self):
        f = contenttype_models.ContentType.objects.get(app_label="rustaq_municipality",model="visit")
        print(f)
        return contenttype_models.ContentType.objects.get(model=self.limitation_type.lower(),app_label=self._meta.app_label).model_class()._meta.verbose_name
    @property
    @admin.display(description="إسم النشاط")
    def _activity_name(self):
        return self.activity.name
    @property
    @admin.display(description="رقم السجل التجاري")
    def _activity_number_register(self):
        return self.activity.number_register
    @property
    @admin.display(description="نوع النشاط")
    def _activity_activitytype(self):
        return self.activity.activitytype
    @property
    @admin.display(description="القرية")
    def _activity_village(self):
        return self.activity.village
    class Meta:
        verbose_name = _("ترخيص")
        verbose_name_plural = _("التراخيص")

    def __str__(self):
        return f"{self.activity.name} | {self.date} | {self.procedure.name}"

    def save(self,*args, **kwargs):

        #print(self.limitation_type,_models.get(model="Visit",app_label="rustaq_municipality"))
        if not self.limitation_type:
            self.limitation_type = self._meta.object_name
        super().save(*args, **kwargs)

class Visit(Licensing):
    file = models.FileField(_("مستند"), upload_to="rustaq_municipality/visit/file", max_length=100,null=True,blank=True)
    detail = models.TextField(_("وصف"))
    notice = models.TextField(_("الملاحظات والإجراءات المتخذة"))

    class Meta:
        verbose_name = _("زيارة")
        verbose_name_plural = _("الزيارات")


class Initiative(Licensing):
    address = models.CharField(_("عنوان المبادرة"), max_length=500)
    coordinator_phone = models.PositiveBigIntegerField(_("رقم هاتف المنسق"))
    file = models.FileField(_("مستند"), upload_to="rustaq_municipality/Initiative/file", max_length=100,null=True,blank=True)
    detail = models.TextField(_("وصف المبادرة"))

    class Meta:
        verbose_name = _("مبادرة")
        verbose_name_plural = _("التوعية والمبادرات")

class Violation(Licensing):
    number = models.PositiveBigIntegerField(_("رقم المخالفة في النظام"))
    amount_fine = models.PositiveSmallIntegerField(_("مقدار الغرامة المالية"))
    file = models.FileField(_("مستند"), upload_to="rustaq_municipality/Violation/file", max_length=100,null=True,blank=True)
    detail = models.TextField(_("وصف المخالفة"))
    notice = models.TextField(_("الملاحظات والإجراءات المتخذة"))

    class Meta:
        verbose_name = _("مخالفة")
        verbose_name_plural = _("المخالفات")


class ComplaintType(models.Model):
    name = models.CharField(_("نوع الشكوى"), max_length=50)
    
    class Meta:
        verbose_name = _("نوع شكوى")
        verbose_name_plural = _("أنواع الشكاوى")

    def __str__(self):
        return self.name

class ComplaintSide(models.Model):
    name = models.CharField(_("اسم الجهة"), max_length=50)
    
    class Meta:
        verbose_name = _("مصدر شكوى")
        verbose_name_plural = _("مصادر الشكوى")

    def __str__(self):
        return self.name


class Complaint(Licensing):
    complainttype = models.ForeignKey(ComplaintType, verbose_name=_("النوع"), on_delete=models.CASCADE)
    date_end = models.DateField(_("تاريخ الأنتهاء"), auto_now=False, auto_now_add=False)
    file = models.FileField(_("مستند"), upload_to="rustaq_municipality/Violation/file", max_length=100,null=True,blank=True)
    complaintside = models.ForeignKey(ComplaintSide, verbose_name=_("مصدر الشكوى"), on_delete=models.CASCADE)
    phone = models.PositiveBigIntegerField(_("رقم الهاتف"))
    detail = models.TextField(_("وصف الشكوى/البلاغ"))
    notice = models.TextField(_("الملاحظات والإجراءات المتخذة"))

    class Meta:
        verbose_name = _("شكوى")
        verbose_name_plural = _("الشكاوى")


class DamageBecause(models.Model):
    name = models.CharField(_("سبب الإتلاف"), max_length=50)
    
    class Meta:
        verbose_name = _("سبب إتلاف")
        verbose_name_plural = _("أسباب الإتلاف/")

    def __str__(self):
        return self.name

class Product(models.Model):
    name = models.CharField(_("اسم المنتج"), max_length=50)
    

    class Meta:
        verbose_name = _("Product")
        verbose_name_plural = _("Products")

    def __str__(self):
        return self.name


class Damage(Licensing):
    damagebecause = models.ForeignKey(DamageBecause, verbose_name=_("السبب"), on_delete=models.CASCADE)
    product = models.ForeignKey(Product, verbose_name=_("المنتج"), on_delete=models.CASCADE)

    class Meta:
        verbose_name = _("إتلاف")
        verbose_name_plural = _("الإتلافات")

class Material(models.Model):
    name = models.CharField(_("إسم المادة"), max_length=50)
    

    class Meta:
        verbose_name = _("Material")
        verbose_name_plural = _("Materials")

    def __str__(self):
        return self.name


class DamageMaterial(models.Model):
    damage = models.ForeignKey(Damage, verbose_name=_("الإتلاف"), on_delete=models.CASCADE)
    material = models.ForeignKey(Material, verbose_name=_("نوع المادة المتلفة"), on_delete=models.CASCADE)
    size = models.PositiveSmallIntegerField(_("حجم المادة المتلفة/كجم"))
    because = models.TextField(_("سبب الإتلاف"))

    setting_number = models.PositiveSmallIntegerField(_("عدد الضبط"))
    release_number = models.PositiveSmallIntegerField(_("عدد الإفراج"))
    damage_number = models.PositiveSmallIntegerField(_("عدد الإتلاف"))

    file = models.FileField(_("مستند"), upload_to="rustaq_municipality/DamageMaterial/file", max_length=100,null=True,blank=True)

    

    class Meta:
        verbose_name = _("مادة")
        verbose_name_plural = _("المواد المتلفة")

    def __str__(self):
        return f"{self.material.name} | {self.because}"
    

class FoodSampleBecause(models.Model):
    name = models.CharField(_("السبب"), max_length=50)
    
    class Meta:
        verbose_name = _("نوع/سبب عينة")
        verbose_name_plural = _("أنواع/أسباب العينات")

    def __str__(self):
        return self.name

class FoodSample(Licensing):
    foodsamplebecause = models.ForeignKey(FoodSampleBecause, verbose_name=_("نوع/سبب العينة"), on_delete=models.CASCADE)
    product = models.ForeignKey(Product, verbose_name=_("المنتج"), on_delete=models.CASCADE)

    class Meta:
        verbose_name = _("FoodSample")
        verbose_name_plural = _("FoodSamples")


class FoodSampleMaterialType(models.Model):
    name = models.CharField(_("نوع العينة"), max_length=50)
    
    class Meta:
        verbose_name = _("نوع عينة")
        verbose_name_plural = _("أنواع عينات الأغذية")

    def __str__(self):
        return self.name

class FoodSampleMaterial(models.Model):
    foodsample = models.ForeignKey(FoodSample, verbose_name=_("عينة الأغذية"), on_delete=models.CASCADE)
    date = models.DateField(_("تاريخ سحب العينة"), auto_now=False, auto_now_add=False)
    foodsamplematerialtype = models.ForeignKey(FoodSampleMaterialType, verbose_name=_("نوع العينة"), on_delete=models.CASCADE)
    result = models.CharField(_("نتيجة العينة"), max_length=500)
    violation = models.CharField(_("المخالفة"), max_length=500)
    procedure = models.CharField(_("الإجراء"), max_length=500)
    file = models.FileField(_("مستند"), upload_to="rustaq_municipality/FoodSampleMaterial/file", max_length=100,null=True,blank=True)

    class Meta:
        verbose_name = _("عينة")
        verbose_name_plural = _("عينات الأغذية")

    def __str__(self):
        return f"{self.foodsamplematerialtype.name} | {self.result}"


class WaterSampleBecause(models.Model):
    name = models.CharField(_("السبب"), max_length=50)
    
    class Meta:
        verbose_name = _("نوع/سبب عينة")
        verbose_name_plural = _("أنواع/أسباب عينات المياه")

    def __str__(self):
        return self.name


class WaterSample(Licensing):
    watersamplebecause = models.ForeignKey(WaterSampleBecause, verbose_name=_("نوع/سبب العينة"), on_delete=models.CASCADE)
    product = models.ForeignKey(Product, verbose_name=_("المنتج"), on_delete=models.CASCADE)

    class Meta:
        verbose_name = _("عينة مياه")
        verbose_name_plural = _("عيناة المياه")


class WaterSampleMaterialType(models.Model):
    name = models.CharField(_("نوع العينة"), max_length=50)
    
    class Meta:
        verbose_name = _("نوع عينة")
        verbose_name_plural = _("أنواع عينات المياه")

    def __str__(self):
        return self.name

class WaterSampleMaterial(models.Model):
    watersample = models.ForeignKey(WaterSample, verbose_name=_("عينة المياة"), on_delete=models.CASCADE)
    date = models.DateField(_("تاريخ سحب العينة"), auto_now=False, auto_now_add=False)
    watersamplematerialtype = models.ForeignKey(WaterSampleMaterialType, verbose_name=_("نوع العينة"), on_delete=models.CASCADE)
    result = models.CharField(_("نتيجة العينة"), max_length=500)
    violation = models.CharField(_("المخالفة"), max_length=500)
    procedure = models.CharField(_("الإجراء"), max_length=500)
    file = models.FileField(_("مستند"), upload_to="rustaq_municipality/WaterSampleMaterial/file", max_length=100,null=True,blank=True)


    class Meta:
        verbose_name = _("عينة")
        verbose_name_plural = _("مواد عينات المياه")

    def __str__(self):
        return f"{self.watersamplematerialtype.name} | {self.result}"



















################################## reports ####################################


