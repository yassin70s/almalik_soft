from django.apps import AppConfig
import os

class AlmalikSoftConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'almalik_soft'
    def ready(self):
        
        return super().ready()