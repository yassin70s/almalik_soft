from collections.abc import MutableMapping
from typing import Any
from django.db import models
from django.contrib.auth import models as auth_models
from django.urls import reverse
from django.contrib.contenttypes import models as contenttype_models
from django.contrib.contenttypes import fields as contenttype_fields
from django.db.models import Model
from django.utils.translation import gettext as _
from django.forms import ValidationError
import zipfile
import json,os,shutil
from django.apps import apps
from django.conf import settings
from django.dispatch import receiver


class Device(models.Model):
    device_type = models.CharField(_("device_type"), max_length=50,choices=[
        ('apk','apk'),
        ('exe','exe'),
        ('web','web'),
    ])
    codename = models.CharField(_("name"), max_length=50,unique=True)
    datetime = models.DateTimeField(_("datetime"), auto_now=False, auto_now_add=True)
    

    class Meta:
        verbose_name = _("Device")
        verbose_name_plural = _("Devices")

    def __str__(self):
        return self.codename




class AccountManagement(models.Model):
    class Meta:
        abstract = True
        verbose_name = "حساب رئيسي"
class AccountBranch(models.Model):
    class Meta:
        abstract = True
        verbose_name = "حساب فرعي"



class Account(auth_models.User):
    #name = models.CharField(_("name"), max_length=50)
    account_type = models.CharField(_("account_type"), max_length=50,choices=[
        (AccountManagement.__name__,AccountManagement._meta.verbose_name),
        (AccountBranch.__name__,AccountBranch._meta.verbose_name),
        
    ],default=AccountManagement.__name__)
    account_manage = models.ForeignKey("Account", verbose_name=_("account_manage"), on_delete=models.CASCADE,null=True,blank=True,related_name="account_account_manage")
    #phone = models.PositiveBigIntegerField(_("phone"))
    #serial = models.CharField(_("serial"), max_length=50)
    date = models.DateField(_("date"), auto_now=False, auto_now_add=True)
    time = models.TimeField(_("time"), auto_now=False, auto_now_add=True)
    
    @property
    def name(self):
        return f"{self.first_name} {self.last_name}"
    class Meta:
        verbose_name = _("Account")
        verbose_name_plural = _("Accounts")

    def __str__(self):
        return self.name

    def save(self,*args, **kwargs):
        #self.account_type = AccountManagement.__name__
        
        super().save(*args, **kwargs)
    def clean(self):
        if not self.first_name:
            raise ValidationError({"first_name":"م"})
        return super().clean()



class Group(auth_models.Group):    

    class Meta:
        verbose_name = _("Group")
        verbose_name_plural = _("Groups")

    def __str__(self):
        return self.name
"""
class Project(models.Model):
    PROJECTS_DIRS = os.path.join(settings.HOME_DIR,"projects")

    base_dir = models.FilePathField(_("base_dir"), path=PROJECTS_DIRS, match=None, max_length=100,editable=False,unique=True)
    name = models.CharField(_("name"), max_length=50,unique=True)
    versions_count = models.PositiveSmallIntegerField(_("versions_count"),editable=False,default=0)
    class Meta:
        verbose_name = _("Project")
        verbose_name_plural = _("Projects")

    def __str__(self):
        return self.name
    
    def save(self,*args, **kwargs):
        base_dir = os.path.join(self.PROJECTS_DIRS,self.name)
        os.makedirs(base_dir,exist_ok=True)
        self.base_dir = base_dir
        super().save(*args, **kwargs)
        shutil.copytree(
            os.path.join(settings.BASE_DIR,'project'),
            self.base_dir,
            dirs_exist_ok=True
        )
    
        
        
        
    
    
class Version(models.Model):
    VERSIONS_DIRS = os.path.join(settings.HOME_DIR,"versions")
    VERSIONS_ZIPS = os.path.join(settings.HOME_DIR,"versions_zips")

    base_dir = models.FilePathField(_("base_dir"), path=Project.PROJECTS_DIRS,allow_folders=True, match=None, max_length=100)
    #app_label = models.CharField(_("app_label"), max_length=50,editable=False)
    version_name = models.CharField(_("version_name"), max_length=50,editable=False)
    datetime_create = models.DateTimeField(_("datetime_create"), auto_now=False, auto_now_add=True)
    version_dir = models.FilePathField(_("version_dir"), path=VERSIONS_DIRS, match=None, allow_folders=True, max_length=100,editable=False)
    version_zip = models.FilePathField(_("version_zip"), path=VERSIONS_ZIPS, match=None, recursive=True, max_length=100,editable=False)
    
    class Meta:
        verbose_name = _("Version")
        verbose_name_plural = _("Versions")
    def __str__(self):
        return self.version_name
    
    
    def save(self,*args, **kwargs):
        project = Project.objects.get(base_dir=self.base_dir)
        project.versions_count = project.versions_count + 1
        project.save()
        self.version_number = project.versions_count
        self.version_name = f"{project.name}-{self.version_number}"
        os.makedirs(self.VERSIONS_ZIPS,exist_ok=True)
        os.makedirs(self.VERSIONS_DIRS,exist_ok=True)
        
        version_dir = os.path.join(self.VERSIONS_DIRS,self.version_name)
        os.makedirs(version_dir,exist_ok=True)
        self.version_dir = version_dir

        version_zip_path = f"{os.path.join(self.VERSIONS_ZIPS,self.version_name)}.zip"
        
        with zipfile.ZipFile(version_zip_path,"w") as zf:
            zf.write(f"{self.version_dir}/")
        self.version_zip = version_zip_path
        
        super().save(*args, **kwargs)

class Install(models.Model):
    INSTALLS_DIRS = os.path.join(settings.HOME_DIR,"installs")
    #INSTALLS_ZIPS = os.path.join(settings.HOME_DIR,"installs_zips")

    datetime_create = models.DateTimeField(_("datetime_create"), auto_now=False, auto_now_add=True)
    install_zip_file = models.FileField(_("install_zip_file"), upload_to="installs_zips_files", max_length=100)
    install_dir = models.FilePathField(_("install_dir"), path=INSTALLS_DIRS,allow_folders=True, match=None, max_length=100,editable=False)
    #install_name = models.CharField(_("install_name"), max_length=50,editable=False)
    

    class Meta:
        verbose_name = _("Install")
        verbose_name_plural = _("Installs")

    

    def save(self,*args, **kwargs):
        
        os.makedirs(self.INSTALLS_DIRS,exist_ok=True)
        if self.pk:
            pk = self.pk
        else:
            pk = Install.objects.count() + 1
        install_dir = os.path.join(self.INSTALLS_DIRS,f"_{pk}")
        os.makedirs(install_dir,exist_ok=True)
        self.install_dir = install_dir
        with zipfile.ZipFile(self.install_zip_file,"r") as file:
            file.extractall(
                install_dir
            )
        super().save(*args, **kwargs)

"""
class App(models.Model):
    APPS_DIRS = os.path.join(settings.BASE_DIR,"apps")

    datetime_create = models.DateTimeField(_("datetime_create"), auto_now=False, auto_now_add=True)
    app_zip_file = models.FileField(_("app_zip_file"), upload_to="apps_zips_files", max_length=100)
    app_dir = models.FilePathField(_("app_dir"), path=APPS_DIRS,allow_folders=True, match=None, max_length=100,editable=False)
    name = models.CharField(_("name"), max_length=50,editable=False)
    app_name = models.CharField(_("app_name"), max_length=50,editable=False)
    app_version = models.PositiveSmallIntegerField(_("app_version"),editable=False)

    class Meta:
        verbose_name = _("App")
        verbose_name_plural = _("Apps")

    

    def save(self,*args, **kwargs):
        
        super().save(*args, **kwargs)
    
    def clean(self):
        if self.app_zip_file:
            error = ""
            with zipfile.ZipFile(self.app_zip_file,"r") as file:
                name = file.namelist()[0][:-1]
                self.name = name
                app_name_list = name.split("__")
                if len(app_name_list) == 2:
                    if f"{name}/apps.py" in file.namelist():
                        app_name = app_name_list[0]
                        self.app_name = app_name
                        app_version = app_name_list[1]
                        if app_version.isnumeric():
                            app_version = int(app_version)
                            self.app_version = app_version
                            app_dir = os.path.join(self.APPS_DIRS,name)
                            if not os.path.isdir(app_dir):
                                os.makedirs(app_dir,exist_ok=True)
                                file.extractall(
                                    os.path.join(self.APPS_DIRS)
                                )
                                self.app_dir = app_dir
                            else:
                                error += "موجود من قبل"
                        else:
                            error = "هذا ليس ملف تطبيق صحيح 1"
                    else:
                        error = "هذا ليس ملف تطبيق صحيح"
                else:
                    error = "هذا ليس ملف تطبيق صحيح 2"
            if not error == "":
                raise ValidationError(error)
        return super().clean()





class Chat(models.Model):
    user = models.ForeignKey(Account, verbose_name=_("user"), on_delete=models.CASCADE)
    datetime_add = models.DateTimeField(_("datetime_add"), auto_now=False, auto_now_add=True)
    datetime_change = models.DateTimeField(_("datetime_change"), auto_now=True, auto_now_add=False)
    to_user = models.ForeignKey(Account, verbose_name=_("to_user"), on_delete=models.CASCADE,related_name="related_chat_to_user")
    text = models.TextField(_("text"),null=True,blank=True)
    class Meta:
        verbose_name = _("Chat")
        verbose_name_plural = _("Chats")

    def __str__(self):
        return f"{self.user} | {self.to_user} | {self.text}"

    

class ChatImage(models.Model):
    chat = models.ForeignKey(Chat, verbose_name=_("chat"), on_delete=models.CASCADE)
    image = models.ImageField(_("image"), upload_to="account/chat/images", height_field=None, width_field=None, max_length=None)

    class Meta:
        verbose_name = _("ChatImage")
        verbose_name_plural = _("ChatImages")

class ChatVideo(models.Model):
    chat = models.ForeignKey(Chat, verbose_name=_("chat"), on_delete=models.CASCADE)
    video = models.FileField(_("video"), upload_to="account/chat/videos", max_length=100)

    class Meta:
        verbose_name = _("ChatVideo")
        verbose_name_plural = _("ChatVideos")


class ChatFile(models.Model):
    chat = models.ForeignKey(Chat, verbose_name=_("chat"), on_delete=models.CASCADE)
    file = models.FileField(_("file"), upload_to="account/chat/file", max_length=100)
    

    class Meta:
        verbose_name = _("ChatFile")
        verbose_name_plural = _("ChatFiles")





@receiver(models.signals.post_migrate)
def create_initial_data(sender, **kwargs):
        if not Account.objects.filter(username = "almalik").exists():
            Account.objects.create_superuser(
                username="almalik",
                password="123456789",
                first_name = "almalik",
            )
        group = Group.objects.get_or_create(name = "almalik_users")[0]
        group.permissions.set(
            auth_models.Permission.objects.filter(codename__in = [
                "add_chat","view_chat",
                "view_account",
            ])
        )