
from typing import Any
from django.contrib.admin import *
from django_api_admin.options import APIModelAdmin
from django_api_admin.sites import APIAdminSite
from django.template.response import TemplateResponse
import subprocess
from django.urls import path,reverse
from django.utils.html import format_html
import json
from django.http.response import JsonResponse,HttpResponseRedirect
from django.utils.timezone import datetime
from . import models
from django.contrib.auth import models as auth_models
from django.conf import settings
from .options import ModelReport,ModelActionReport
class ModelAdmin(ModelAdmin):
    def changelist_view(self, request, extra_context=None):
        self.change_list_template = None or [
            f"{self.admin_site.name}/{self.opts.app_label}/{self.opts.model_name}/change_list.html",
            f"{self.admin_site.name}/{self.opts.app_label}/change_list.html",
            f"{self.admin_site.name}/change_list.html",
            f"change_list.html",
            f"admin/change_list.html",
        ]
        return super().changelist_view(request, extra_context)
    def changeform_view(self, request, object_id = None, form_url = "", extra_context = None):
        self.change_form_template = None or [
            f"{self.admin_site.name}/{self.opts.app_label}/{self.opts.model_name}/change_form.html",
            f"{self.admin_site.name}/{self.opts.app_label}/change_form.html",
            f"{self.admin_site.name}/change_form.html",
            f"change_form.html",
            f"admin/change_form.html",

        ]
        return super().changeform_view(request, object_id, form_url, extra_context)

class ModelApi(APIModelAdmin):
    pass
class ModelView(ModelAdmin):
    pass

class AdminSite(AdminSite):
    site_header = "Almalik"
    site_title = "Almalik"
    index_title = "الرئيسية"
    def __init__(self,name):
        super().__init__(name)
        
    def index(self, request, extra_context = None):
        self.index_template = None or [
            f"{self.name}/index.html",
            f"admin/index.html",
        ]
        return super().index(request, extra_context)
    def app_index(self, request, app_label, extra_context = None):
        self.app_index_template = None or [
            f"{self.name}/{app_label}/index.html",
            f"{self.name}/app_index.html",
        ]
        return super().app_index(request, app_label, extra_context)
    
    def login(self, request, extra_context = None):
        
        return super().login(request, extra_context)
    def logout(self, request, extra_context = None):
        return super().logout(request, extra_context)
admin_site = AdminSite(name="admin_site")


class ApiSite(APIAdminSite,AdminSite):
    
    def get_urls(self):
        
        
        my_urls = [
            path("login/",self.api_admin_view(self.login),name="login"),
            path("register_user/",self.api_admin_view(self.register_user),name="register_user"),
           

        ]
        return my_urls + super().get_urls()
    
    def register_user(self,request):
        data = json.loads(request.body).get("data")
        print(data)
        print(data)
        errors = {}
        errors_count = 0
        if not "first_name" in data :
            errors["first_name"] = ["الاسم الاول مطلوب"]
            errors_count += 1
        if not "last_name" in data :
            errors["last_name"] = ["الاسم الاخير مطلوب"]
            errors_count += 1
        if not "number_phone" in data:
            errors["number_phone"] = ["رقم الهاتف مطلوب"]
            errors_count += 1
        if not "password_register" in data:
            errors["password_register"] = ["ادخل كلمة السر"]
            errors_count += 1

        if errors_count == 0:
            number_phone = data["number_phone"]
            password_register = data["password_register"]
            if len(number_phone) == 9 and number_phone[0] == "7":
                if number_phone[1] == "7" or number_phone[1] == '8' or number_phone[1] == "3" or number_phone[1] == "1" or number_phone[1] == "0":
                    pass
                else:
                    errors["number_phone"] = ["رقم الهاتف غير صحيح"]
                    errors_count += 1
            else:
                errors["number_phone"] = ["رقم الهاتف غير صحيح"]
                errors_count += 1
            if models.Account.objects.filter(username=number_phone).exists():
                errors["number_phone"] = ["رقم الهاتف موجود من قبل"]
                errors_count += 1
            elif not len(password_register) >=7:
                errors["password_register"] = ["يجب أن تكون كلمة المرور 7 محارف على الأقل"]
                errors_count += 1
        if errors_count == 0:
            """print(errors_count,number_phone,auth_models.User.objects.filter(username=number_phone).exists())
            model_user = models.User()
            model_user.username = number_phone
            model_user.password = data["password_register"]
            model_user.first_name=data["first_name"]
            model_user.last_name = data["last_name"]
            model_user.is_active = True
            model_user.is_staff = True
            model_user.save()"""
            models.Account.objects.create_user(
                username = number_phone,
                password=data["password_register"],
                first_name=data["first_name"],
                last_name = data["last_name"],

                is_active = True,
                is_staff = True,

            ).groups.add(auth_models.Group.objects.get(name="almalik_users"))
            user = auth_models.User.objects.get(username=number_phone)
            
            
            return JsonResponse(data={"data":data})
        else:
            errors_content = ""
            for key,value in errors.items():
                errors_content += f"<div class='row'> - {value[0]}</div>"
            return JsonResponse(data={"errors":errors,"detail":errors_content})

api_site = ApiSite(name="api_site")

class ViewSite(AdminSite):

    login_template = "view_site/login.html"
    def index(self, request, extra_context=None):
        extra_context = extra_context or {}

        extra_context.update(
            project_name = "elham_soft"
        )
        return super().index(request, extra_context)
    def each_context(self, request):
        return {
            #"notice_change_list_api_url":reverse(f"api:almalik_noticeuser_changelist"),
            **super().each_context(request)
        }
    def login(self, request, extra_context=None):
        extra_context = extra_context or {}
        


        context = {
            "register_user_url":reverse("api_site:register_user"),
            "login_api_url":reverse("api_site:login"),
            "location_url":reverse("admin:index",current_app=self.name),
        }


        extra_context.update(context)
        is_login = True
        is_soon = True
        is_knowledge = True




        extra_context.update(
            is_login = is_login,
            is_soon = is_soon,
            is_knowledge = is_knowledge,
            

        )
        return super().login(request, extra_context)

view_site = ViewSite(name="view_site")


class AppAdmin(ModelAdmin):
    list_display = ["name","app_dir","datetime_create"]
    def has_change_permission(self, request, obj = None):
        return False
    def has_delete_permission(self, request, obj = None):
        return False
#view_site.register(models.App,AppAdmin)

class AccountAdmin(ModelAdmin):
    list_display = ["messages_list"]
    def changelist_view(self, request, extra_context=None):
        return super().changelist_view(request, extra_context)
    def get_queryset(self, request):
        self.user = request.user

        return super().get_queryset(request)
    def messages_list(self,obj):
        return {
            "userId":obj.id,
            "name":obj.name,
            "path":"",
            "time":"",
            "preview":"",
            "messages":[
                {
                    "fromUserId": chat.to_user.pk,
                    "toUserId": chat.user.pk,
                    "text": chat.text
                } for chat in models.Chat.objects.union(
                    models.Chat.objects.filter(user=obj,to_user=self.user),models.Chat.objects.filter(to_user=obj,user=self.user)
                )
            ]
        }
#view_site.register(models.Account,AccountAdmin)

class AccountApi(ModelApi,AccountAdmin):
    pass
#api_site.register(models.Account,AccountApi)

class ChatAdmin(ModelAdmin):
    def changelist_view(self, request, extra_context=None):
        extra_context = {
            "add_api_url":reverse(f"api_site:{self.opts.app_label}_chat_add"),
        }
        print(555)
        return super().changelist_view(request, extra_context)
#view_site.register(models.Chat,ChatAdmin)

class ChatApi(ModelApi,ChatAdmin):
    pass
#api_site.register(models.Chat,ChatApi)
