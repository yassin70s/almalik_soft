const a = 444

export function aa() {
    return 9999
}